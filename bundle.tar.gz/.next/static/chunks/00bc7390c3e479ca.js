(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,67240,e=>{"use strict";let t=(0,e.i(75254).default)("rotate-ccw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);e.s(["RotateCcw",()=>t],67240)},10980,e=>{"use strict";let t=(0,e.i(75254).default)("book-open",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]]);e.s(["BookOpen",()=>t],10980)},55436,e=>{"use strict";let t=(0,e.i(75254).default)("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]);e.s(["Search",()=>t],55436)},31245,e=>{"use strict";let t=(0,e.i(75254).default)("bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]]);e.s(["Bot",()=>t],31245)},83086,e=>{"use strict";let t=(0,e.i(75254).default)("sparkles",[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]]);e.s(["Sparkles",()=>t],83086)},31278,e=>{"use strict";let t=(0,e.i(75254).default)("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);e.s(["Loader2",()=>t],31278)},43432,e=>{"use strict";let t=(0,e.i(75254).default)("phone",[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]);e.s(["Phone",()=>t],43432)},32095,e=>{"use strict";let t=(0,e.i(75254).default)("graduation-cap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]);e.s(["GraduationCap",()=>t],32095)},55711,e=>{"use strict";let t=(0,e.i(75254).default)("brain",[["path",{d:"M12 18V5",key:"adv99a"}],["path",{d:"M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4",key:"1e3is1"}],["path",{d:"M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5",key:"1gqd8o"}],["path",{d:"M17.997 5.125a4 4 0 0 1 2.526 5.77",key:"iwvgf7"}],["path",{d:"M18 18a4 4 0 0 0 2-7.464",key:"efp6ie"}],["path",{d:"M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517",key:"1gq6am"}],["path",{d:"M6 18a4 4 0 0 1-2-7.464",key:"k1g0md"}],["path",{d:"M6.003 5.125a4 4 0 0 0-2.526 5.77",key:"q97ue3"}]]);e.s(["Brain",()=>t],55711)},61911,e=>{"use strict";let t=(0,e.i(75254).default)("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]);e.s(["Users",()=>t],61911)},42009,e=>{"use strict";let t=(0,e.i(75254).default)("award",[["path",{d:"m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",key:"1yiouv"}],["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}]]);e.s(["Award",()=>t],42009)},70273,e=>{"use strict";let t=(0,e.i(75254).default)("star",[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]]);e.s(["Star",()=>t],70273)},63059,e=>{"use strict";let t=(0,e.i(75254).default)("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);e.s(["ChevronRight",()=>t],63059)},58472,e=>{"use strict";let t=(0,e.i(75254).default)("code",[["path",{d:"m16 18 6-6-6-6",key:"eg8j8"}],["path",{d:"m8 6-6 6 6 6",key:"ppft3o"}]]);e.s(["Code",()=>t],58472)},98919,e=>{"use strict";let t=(0,e.i(75254).default)("shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);e.s(["Shield",()=>t],98919)},1928,e=>{"use strict";let t=(0,e.i(75254).default)("shopping-cart",[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]]);e.s(["ShoppingCart",()=>t],1928)},58377,e=>{"use strict";let t=(0,e.i(75254).default)("flame",[["path",{d:"M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",key:"1slcih"}]]);e.s(["Flame",()=>t],58377)},22258,e=>{"use strict";let t=(0,e.i(75254).default)("chart-column",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);e.s(["BarChart3",()=>t],22258)},31091,e=>{"use strict";let t=(0,e.i(75254).default)("megaphone",[["path",{d:"M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",key:"q8bfy3"}],["path",{d:"M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14",key:"1853fq"}],["path",{d:"M8 6v8",key:"15ugcq"}]]);e.s(["Megaphone",()=>t],31091)},95468,e=>{"use strict";let t=(0,e.i(75254).default)("circle-check",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);e.s(["CheckCircle2",()=>t],95468)},20278,e=>{"use strict";let t=(0,e.i(75254).default)("target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]]);e.s(["Target",()=>t],20278)},41202,e=>{"use strict";let t=(0,e.i(75254).default)("globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);e.s(["Globe",()=>t],41202)},86536,e=>{"use strict";let t=(0,e.i(75254).default)("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);e.s(["Eye",()=>t],86536)},12426,e=>{"use strict";let t=(0,e.i(75254).default)("dollar-sign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]]);e.s(["DollarSign",()=>t],12426)},21557,e=>{"use strict";let t=(0,e.i(75254).default)("calculator",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",key:"1nb95v"}],["line",{x1:"8",x2:"16",y1:"6",y2:"6",key:"x4nwl0"}],["line",{x1:"16",x2:"16",y1:"14",y2:"18",key:"wjye3r"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M8 18h.01",key:"lrp35t"}]]);e.s(["Calculator",()=>t],21557)},86311,e=>{"use strict";let t=(0,e.i(75254).default)("message-square",[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]]);e.s(["MessageSquare",()=>t],86311)},58041,e=>{"use strict";let t=(0,e.i(75254).default)("database",[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]]);e.s(["Database",()=>t],58041)},63488,e=>{"use strict";let t=(0,e.i(75254).default)("mail",[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]]);e.s(["Mail",()=>t],63488)},40524,e=>{"use strict";let t=(0,e.i(75254).default)("workflow",[["rect",{width:"8",height:"8",x:"3",y:"3",rx:"2",key:"by2w9f"}],["path",{d:"M7 11v4a2 2 0 0 0 2 2h4",key:"xkn7yn"}],["rect",{width:"8",height:"8",x:"13",y:"13",rx:"2",key:"1cgmvn"}]]);e.s(["Workflow",()=>t],40524)},31343,e=>{"use strict";let t=(0,e.i(75254).default)("play",[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]]);e.s(["Play",()=>t],31343)},7233,27612,e=>{"use strict";var t=e.i(75254);let a=(0,t.default)("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);e.s(["Plus",()=>a],7233);let s=(0,t.default)("trash-2",[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]]);e.s(["Trash2",()=>s],27612)},33467,e=>{"use strict";let t=(0,e.i(75254).default)("chart-no-axes-column-increasing",[["path",{d:"M5 21v-6",key:"1hz6c0"}],["path",{d:"M12 21V9",key:"uvy0l4"}],["path",{d:"M19 21V3",key:"11j9sm"}]]);e.s(["BarChart",()=>t],33467)},16488,e=>{"use strict";var t=e.i(43476),a=e.i(71645),s=e.i(7233),o=e.i(31343),r=e.i(69638),i=e.i(27612),n=e.i(40524),l=e.i(67240);let d=[{id:"email",type:"trigger",label:"New Email",icon:"📧"},{id:"form",type:"trigger",label:"Form Submit",icon:"📝"},{id:"webhook",type:"trigger",label:"Webhook",icon:"🔗"},{id:"ai",type:"action",label:"AI Analysis",icon:"🤖"},{id:"db",type:"action",label:"Save to DB",icon:"💾"},{id:"sms",type:"action",label:"Send SMS",icon:"📱"},{id:"slack",type:"action",label:"Slack Notify",icon:"💬"},{id:"filter",type:"condition",label:"Filter",icon:"🔍"}],c={trigger:"border-emerald-500/20 bg-emerald-500/5 hover:border-emerald-500/40",action:"border-blue-500/20 bg-blue-500/5 hover:border-blue-500/40",condition:"border-amber-500/20 bg-amber-500/5 hover:border-amber-500/40"},u={trigger:{label:"TRIGGER",color:"text-emerald-500 bg-emerald-500/10"},action:{label:"ACTION",color:"text-blue-500 bg-blue-500/10"},condition:{label:"CONDITION",color:"text-amber-500 bg-amber-500/10"}};function m(){let[e,m]=(0,a.useState)([]),[p,h]=(0,a.useState)(!1),[g,x]=(0,a.useState)(null),[b,f]=(0,a.useState)(new Set),y=async()=>{if(0!==e.length){h(!0),x(null),f(new Set);for(let t=0;t<e.length;t++)x(t),await new Promise(e=>setTimeout(e,800)),f(e=>new Set(e).add(t));x(null),h(!1)}};return(0,t.jsx)("section",{id:"modules",className:"section-padding bg-transparent",children:(0,t.jsxs)("div",{className:"container-custom",children:[(0,t.jsxs)("div",{className:"max-w-2xl mx-auto text-center mb-16 opacity-0 animate-fade-in-up",children:[(0,t.jsxs)("p",{className:"section-badge mb-4",children:[(0,t.jsx)(n.Workflow,{className:"h-3.5 w-3.5"})," Visual Builder"]}),(0,t.jsxs)("h2",{className:"text-3xl md:text-5xl font-bold mb-4",children:["Build Your ",(0,t.jsx)("span",{className:"text-primary",children:"Workflow"})]}),(0,t.jsx)("p",{className:"text-muted-foreground text-lg",children:"Assemble your perfect automation pipeline and simulate it live."})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-6 opacity-0 animate-fade-in-up delay-100",children:[(0,t.jsxs)("div",{className:"bg-card border border-border rounded-2xl p-6 h-fit",children:[(0,t.jsxs)("h3",{className:"font-bold text-xs uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2",children:[(0,t.jsx)(s.Plus,{className:"h-3.5 w-3.5"})," Available Modules"]}),(0,t.jsx)("div",{className:"grid grid-cols-2 gap-3",children:d.map(a=>(0,t.jsxs)("button",{onClick:()=>{m([...e,{...a,id:`${a.id}-${Date.now()}`}])},className:`flex flex-col items-center justify-center p-4 rounded-xl border transition-all text-sm font-medium hover:scale-105 active:scale-95 ${c[a.type]}`,children:[(0,t.jsx)("span",{className:"text-2xl mb-2",children:a.icon}),(0,t.jsx)("span",{className:"text-xs font-bold",children:a.label})]},a.id))})]}),(0,t.jsxs)("div",{className:"lg:col-span-2 bg-card border border-border rounded-2xl p-6 flex flex-col relative overflow-hidden min-h-[500px]",children:[(0,t.jsx)("div",{className:"absolute inset-0 opacity-[0.4] pointer-events-none",style:{backgroundImage:"radial-gradient(#CBD5E1 1px, transparent 1px)",backgroundSize:"20px 20px"}}),(0,t.jsxs)("div",{className:"flex items-center justify-between mb-6 relative z-10",children:[(0,t.jsx)("div",{className:"flex items-center gap-2 text-xs font-mono text-muted-foreground bg-muted/50 px-3 py-1.5 rounded-lg border border-border",children:"canvas.flow"}),(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsxs)("span",{className:"text-xs text-muted-foreground font-medium",children:[e.length," nodes"]}),e.length>0&&(0,t.jsxs)("button",{onClick:()=>{m([]),f(new Set),x(null)},className:"text-xs font-medium text-muted-foreground hover:text-red-500 transition-colors flex items-center gap-1",children:[(0,t.jsx)(l.RotateCcw,{className:"h-3 w-3"})," Clear"]})]})]}),(0,t.jsx)("div",{className:"flex-1 overflow-y-auto relative z-10 custom-scrollbar pr-2",children:0===e.length?(0,t.jsxs)("div",{className:"h-full flex flex-col items-center justify-center text-muted-foreground/40 border-2 border-dashed border-border rounded-xl min-h-[300px]",children:[(0,t.jsx)(s.Plus,{className:"h-10 w-10 mb-3"}),(0,t.jsx)("p",{className:"font-medium text-sm",children:"Add modules to start building"})]}):(0,t.jsx)("div",{className:"flex flex-col items-center space-y-3 pb-4",children:e.map((a,s)=>{let o=g===s,n=b.has(s);return(0,t.jsxs)("div",{className:"relative w-full max-w-sm animate-fade-in",children:[(0,t.jsxs)("div",{className:`
                                                    relative bg-background p-4 rounded-xl border shadow-sm flex items-center justify-between group transition-all duration-300
                                                    ${o?"border-primary ring-1 ring-primary shadow-md scale-105":n?"border-green-500/30 bg-green-500/5":"border-border"}
                                                `,children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("div",{className:`h-10 w-10 rounded-lg flex items-center justify-center text-lg transition-colors duration-500 ${n?"bg-green-100 dark:bg-green-900/30 text-green-600":"bg-muted"}`,children:n?(0,t.jsx)(r.CheckCircle,{className:"h-5 w-5 animate-zoom-in"}):a.icon}),(0,t.jsxs)("div",{children:[(0,t.jsx)("span",{className:"font-bold text-sm block",children:a.label}),(0,t.jsx)("span",{className:`text-[10px] font-bold px-1.5 py-0.5 rounded ${u[a.type].color} inline-block mt-0.5`,children:u[a.type].label})]})]}),o&&(0,t.jsx)("div",{className:"w-4 h-4 rounded-full border-2 border-primary border-t-transparent animate-spin"}),!p&&(0,t.jsx)("button",{"aria-label":"Remove node",onClick:()=>{let t;(t=[...e]).splice(s,1),m(t),f(new Set)},className:"text-muted-foreground hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-md hover:bg-muted",children:(0,t.jsx)(i.Trash2,{className:"h-3.5 w-3.5"})})]}),s<e.length-1&&(0,t.jsx)("div",{className:"h-6 w-0.5 bg-border mx-auto my-1"})]},a.id)})})}),(0,t.jsxs)("div",{className:"mt-6 pt-4 border-t border-border flex justify-between items-center relative z-10",children:[(0,t.jsx)("div",{children:b.size>0&&!p&&(0,t.jsxs)("span",{className:"text-green-600 text-xs font-bold flex items-center gap-1.5 animate-fade-in",children:[(0,t.jsx)(r.CheckCircle,{className:"h-3.5 w-3.5"})," Simulation Complete"]})}),(0,t.jsx)("button",{onClick:y,disabled:p||0===e.length,className:"btn-primary disabled:opacity-50 disabled:cursor-not-allowed text-xs px-5 py-2.5 h-10 transition-transform active:scale-95",children:p?"Running...":(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(o.Play,{className:"h-3.5 w-3.5 mr-2 fill-current"})," Run Workflow"]})})]})]})]})]})})}e.s(["WorkflowBuilder",()=>m])},3116,e=>{"use strict";let t=(0,e.i(75254).default)("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);e.s(["Clock",()=>t],3116)},25652,e=>{"use strict";let t=(0,e.i(75254).default)("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]);e.s(["TrendingUp",()=>t],25652)},41240,e=>{"use strict";let t=(0,e.i(75254).default)("lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]]);e.s(["Lightbulb",()=>t],41240)},87130,e=>{"use strict";let t=(0,e.i(75254).default)("funnel",[["path",{d:"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",key:"sc7q7i"}]]);e.s(["Filter",()=>t],87130)},78583,e=>{"use strict";let t=(0,e.i(75254).default)("file-text",[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);e.s(["FileText",()=>t],78583)},78716,78917,14453,e=>{"use strict";var t=e.i(75254);let a=(0,t.default)("video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]);e.s(["Video",()=>a],78716);let s=(0,t.default)("external-link",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);function o(e){return e.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")}e.s(["ExternalLink",()=>s],78917),e.s(["generateSlug",()=>o],14453)},33213,e=>{"use strict";var t=e.i(43476),a=e.i(71645);function s({className:e="",id:s,style:o}){return(0,a.useEffect)(()=>{try{(window.adsbygoogle=window.adsbygoogle||[]).push({})}catch(e){console.error("AdSense error:",e)}},[]),(0,t.jsx)("div",{className:`my-8 w-full overflow-hidden ${e}`,children:(0,t.jsx)("ins",{className:"adsbygoogle",style:o||{display:"block",minHeight:"90px"},"data-ad-client":"ca-pub-5677457553651550","data-ad-slot":s||"auto","data-ad-format":"auto","data-full-width-responsive":"true"})})}e.s(["AdSlot",()=>s])},258,e=>{"use strict";var t=e.i(43476),a=e.i(71645),s=e.i(21557),o=e.i(25652),r=e.i(12426),i=e.i(3116),n=e.i(61911),l=e.i(72520);function d(){let[e,d]=(0,a.useState)(10),[c,u]=(0,a.useState)(25),[m,p]=(0,a.useState)(2),h=e*c*m*52,g=.8*h,x=e*m*41.6;return(0,t.jsx)("section",{id:"tools",className:"section-padding bg-transparent",children:(0,t.jsxs)("div",{className:"container-custom",children:[(0,t.jsxs)("div",{className:"max-w-2xl mx-auto text-center mb-16 opacity-0 animate-fade-in-up",children:[(0,t.jsxs)("p",{className:"section-badge mb-4",children:[(0,t.jsx)(s.Calculator,{className:"h-3.5 w-3.5"})," ROI Calculator"]}),(0,t.jsxs)("h2",{className:"text-3xl md:text-5xl font-bold mb-4",children:["Calculate Your ",(0,t.jsx)("span",{className:"text-primary",children:"Savings"})]}),(0,t.jsx)("p",{className:"text-muted-foreground text-lg",children:"See exactly how much manual tasks are costing your business."})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-8 items-start max-w-5xl mx-auto opacity-0 animate-fade-in-up delay-100",children:[(0,t.jsx)("div",{className:"space-y-6",children:(0,t.jsxs)("div",{className:"bg-card border border-border rounded-2xl p-8",children:[(0,t.jsxs)("h3",{className:"font-bold text-lg mb-8 flex items-center gap-2",children:[(0,t.jsx)(o.TrendingUp,{className:"h-4 w-4 text-primary"})," Configure Data"]}),(0,t.jsxs)("div",{className:"space-y-8",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between mb-2",children:[(0,t.jsxs)("label",{className:"text-sm font-medium flex items-center gap-2",children:[(0,t.jsx)(i.Clock,{className:"h-4 w-4 text-muted-foreground"})," Hours/Week (Manual)"]}),(0,t.jsxs)("span",{className:"text-sm font-bold bg-muted px-2 py-1 rounded-md min-w-[3rem] text-center",children:[e,"h"]})]}),(0,t.jsx)("input",{"aria-label":"Hours per week spent on manual tasks",type:"range",min:"1",max:"100",value:e,onChange:e=>d(Number(e.target.value)),className:"w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between mb-2",children:[(0,t.jsxs)("label",{className:"text-sm font-medium flex items-center gap-2",children:[(0,t.jsx)(r.DollarSign,{className:"h-4 w-4 text-muted-foreground"})," Hourly Rate"]}),(0,t.jsxs)("span",{className:"text-sm font-bold bg-muted px-2 py-1 rounded-md min-w-[3rem] text-center",children:["$",c]})]}),(0,t.jsx)("input",{"aria-label":"Hourly rate",type:"range",min:"10",max:"200",value:c,onChange:e=>u(Number(e.target.value)),className:"w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"flex justify-between mb-2",children:[(0,t.jsxs)("label",{className:"text-sm font-medium flex items-center gap-2",children:[(0,t.jsx)(n.Users,{className:"h-4 w-4 text-muted-foreground"})," Employees"]}),(0,t.jsx)("span",{className:"text-sm font-bold bg-muted px-2 py-1 rounded-md min-w-[3rem] text-center",children:m})]}),(0,t.jsx)("input",{"aria-label":"Number of employees",type:"range",min:"1",max:"50",value:m,onChange:e=>p(Number(e.target.value)),className:"w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"})]})]})]})}),(0,t.jsxs)("div",{className:"bg-primary text-primary-foreground rounded-2xl p-8 shadow-xl relative overflow-hidden transition-transform hover:scale-[1.01] duration-500",children:[(0,t.jsx)("div",{className:"absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"}),(0,t.jsx)("div",{className:"absolute bottom-0 left-0 w-64 h-64 bg-black/10 rounded-full blur-3xl -ml-16 -mb-16 pointer-events-none"}),(0,t.jsxs)("div",{className:"relative z-10",children:[(0,t.jsx)("h3",{className:"text-lg font-medium mb-6 opacity-90",children:"Estimated Annual Impact"}),(0,t.jsxs)("div",{className:"grid gap-6 mb-8",children:[(0,t.jsxs)("div",{className:"bg-white/10 rounded-xl p-5 border border-white/10 backdrop-blur-sm",children:[(0,t.jsx)("p",{className:"text-xs uppercase tracking-wider font-bold opacity-70 mb-1",children:"Potential Savings"}),(0,t.jsxs)("p",{className:"text-4xl md:text-5xl font-bold tracking-tight mb-1 animate-fade-in",children:["$",Math.round(g).toLocaleString()]},g),(0,t.jsx)("p",{className:"text-sm opacity-80",children:"Per year with automation"})]}),(0,t.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{className:"bg-white/5 rounded-xl p-4 border border-white/5",children:[(0,t.jsxs)("p",{className:"text-2xl font-bold animate-fade-in",children:[Math.round(x/52),"h"]},x),(0,t.jsx)("p",{className:"text-xs opacity-70",children:"Hours Saved / Week"})]}),(0,t.jsxs)("div",{className:"bg-white/5 rounded-xl p-4 border border-white/5",children:[(0,t.jsxs)("p",{className:"text-2xl font-bold animate-fade-in",children:["$",Math.round(h).toLocaleString()]},h),(0,t.jsx)("p",{className:"text-xs opacity-70",children:"Current Annual Cost"})]})]})]}),(0,t.jsxs)("button",{className:"w-full py-4 rounded-xl bg-white text-primary font-bold text-sm hover:bg-white/90 transition-colors flex items-center justify-center gap-2 shadow-sm active:scale-95",children:["Get Full Audit ",(0,t.jsx)(l.ArrowRight,{className:"h-4 w-4"})]})]})]})]})]})})}e.s(["ROICalculator",()=>d])},66508,e=>{"use strict";var t=e.i(43476),a=e.i(86536),s=e.i(41240),o=e.i(58524),r=e.i(41202),i=e.i(32095),n=e.i(75254);let l=(0,n.default)("leaf",[["path",{d:"M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z",key:"nnexq3"}],["path",{d:"M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12",key:"mt58a7"}]]),d=(0,n.default)("rocket",[["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}],["path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}],["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}]]),c=[{icon:s.Lightbulb,title:"Innovation at the Core",desc:"Constantly pushing boundaries with AI, cloud, and automation to design solutions that feel futuristic yet practical.",color:"text-primary",bg:"bg-primary/8"},{icon:o.Link2,title:"Seamless Integration",desc:"Creating ecosystems where social media, e-commerce, customer engagement, and education flow together effortlessly.",color:"text-blue-500",bg:"bg-blue-500/8"},{icon:r.Globe,title:"Global Appeal",desc:"Building polished, branded experiences that resonate with startups, enterprises, and learners worldwide.",color:"text-violet-500",bg:"bg-violet-500/8"},{icon:i.GraduationCap,title:"Empowerment Through Education",desc:"Sharing knowledge via courses, demos, and interactive tools so that anyone can harness automation for growth.",color:"text-emerald-500",bg:"bg-emerald-500/8"},{icon:l,title:"Sustainability & Responsibility",desc:"Designing technology that is mindful of people, communities, and the environment.",color:"text-amber-600",bg:"bg-amber-500/8"}];function u(){return(0,t.jsx)("section",{className:"section-padding bg-transparent",children:(0,t.jsxs)("div",{className:"container-custom",children:[(0,t.jsxs)("div",{className:"max-w-3xl mx-auto text-center mb-16 opacity-0 animate-fade-in-up",children:[(0,t.jsxs)("p",{className:"section-badge mb-4",children:[(0,t.jsx)(a.Eye,{className:"h-3.5 w-3.5"})," Our Vision"]}),(0,t.jsxs)("h2",{className:"text-3xl md:text-5xl font-bold mb-6",children:["Vision of ",(0,t.jsx)("span",{className:"text-primary",children:"Atul Automation"})]}),(0,t.jsx)("p",{className:"text-muted-foreground text-lg leading-relaxed",children:"Atul Automation envisions a world where technology and creativity converge to empower businesses and individuals. We strive to be the leading force in AI-powered automation, building platforms that are not only efficient but also inspiring, interactive, and globally accessible."})]}),(0,t.jsx)("div",{className:"max-w-2xl mx-auto text-center mb-10 opacity-0 animate-fade-in-up delay-100",children:(0,t.jsxs)("h3",{className:"text-2xl md:text-3xl font-bold",children:["Core Elements of Our ",(0,t.jsx)("span",{className:"text-primary",children:"Vision"})]})}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto mb-16",children:c.map((e,a)=>{let s=e.icon;return(0,t.jsxs)("div",{className:`group bg-card border border-border rounded-2xl p-6 hover:shadow-lg hover:border-primary/20 transition-all duration-300 opacity-0 animate-fade-in-up delay-${(a+1)*100}`,children:[(0,t.jsx)("div",{className:`w-12 h-12 rounded-xl ${e.bg} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`,children:(0,t.jsx)(s,{className:`h-6 w-6 ${e.color}`})}),(0,t.jsx)("h4",{className:"text-lg font-bold mb-2 text-foreground group-hover:text-primary transition-colors",children:e.title}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground leading-relaxed",children:e.desc})]},a)})}),(0,t.jsx)("div",{className:"max-w-4xl mx-auto opacity-0 animate-fade-in-up delay-300",children:(0,t.jsxs)("div",{className:"relative bg-gradient-to-br from-primary/5 via-card to-secondary/5 border border-primary/20 rounded-2xl p-8 md:p-12 text-center overflow-hidden",children:[(0,t.jsx)("div",{className:"absolute top-0 right-0 w-48 h-48 bg-primary/10 rounded-full blur-[80px] pointer-events-none"}),(0,t.jsx)("div",{className:"absolute bottom-0 left-0 w-48 h-48 bg-secondary/10 rounded-full blur-[80px] pointer-events-none"}),(0,t.jsxs)("div",{className:"relative z-10",children:[(0,t.jsxs)("div",{className:"inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-6",children:[(0,t.jsx)(d,{className:"h-4 w-4 text-primary"}),(0,t.jsx)("span",{className:"text-sm font-semibold text-primary",children:"Our Aspiration"})]}),(0,t.jsxs)("p",{className:"text-lg md:text-xl leading-relaxed text-foreground font-medium max-w-3xl mx-auto",children:["To transform Atul Automation into a ",(0,t.jsx)("span",{className:"text-primary font-bold",children:"global hub"})," of intelligent workflows, creative branding, and interactive learning — inspiring the next generation of innovators to ",(0,t.jsx)("span",{className:"text-primary font-bold",children:"dream bigger"})," and ",(0,t.jsx)("span",{className:"text-primary font-bold",children:"build smarter"}),"."]})]})]})})]})})}e.s(["Branding",()=>u],66508)},57841,e=>{"use strict";var t=e.i(43476),a=e.i(71645),s=e.i(14764),o=e.i(63488),r=e.i(43432);let i=(0,e.i(75254).default)("map-pin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]);var n=e.i(72520),l=e.i(69638),d=e.i(83086),c=e.i(98919),u=e.i(3116),m=e.i(42009);function p(){let[e,p]=(0,a.useState)(!1),[h,g]=(0,a.useState)(!1),[x,b]=(0,a.useState)({name:"",email:"",service:"Select a Service",message:""}),f=async e=>{e.preventDefault(),g(!0);try{let e=await fetch("/api/contact",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(x)}),t=await e.json();e.ok&&t.success?p(!0):alert(t.message||"Failed to send message. Please try again.")}catch(e){console.error("Error submitting form:",e),alert("Something went wrong. Please try again later.")}finally{g(!1)}},y=e=>{b({...x,[e.target.name]:e.target.value})};return(0,t.jsxs)("section",{id:"contact",className:"section-padding bg-transparent relative",children:[(0,t.jsx)("div",{className:"absolute top-0 left-1/2 -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent rounded-full"}),(0,t.jsxs)("div",{className:"container-custom",children:[(0,t.jsxs)("div",{className:"relative bg-gradient-to-br from-primary via-orange-500 to-primary rounded-3xl p-10 md:p-14 text-center text-white mb-16 overflow-hidden opacity-0 animate-fade-in-up",children:[(0,t.jsx)("div",{className:"absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12 animate-shimmer pointer-events-none"}),(0,t.jsx)("div",{className:"absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/3"}),(0,t.jsx)("div",{className:"absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/3"}),(0,t.jsxs)("div",{className:"relative z-10",children:[(0,t.jsxs)("div",{className:"inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm px-4 py-2 rounded-full mb-6 animate-pulse",children:[(0,t.jsx)(d.Sparkles,{className:"h-3.5 w-3.5"}),(0,t.jsx)("span",{className:"text-xs font-bold tracking-wider uppercase",children:"Limited Time Offer"})]}),(0,t.jsx)("h2",{className:"text-3xl md:text-5xl font-bold mb-4",children:"Ready to 10x Your Business?"}),(0,t.jsx)("p",{className:"text-white/80 text-lg mb-8 max-w-lg mx-auto",children:"Get a free automation strategy call. No commitment, just clarity."}),(0,t.jsxs)("a",{href:"#contact-form",className:"inline-flex items-center gap-2 bg-white text-primary font-bold px-8 py-3.5 rounded-full hover:bg-white/90 hover:shadow-2xl hover:shadow-white/20 transition-all group",children:["Book Free Call ",(0,t.jsx)(n.ArrowRight,{className:"h-4 w-4 group-hover:translate-x-0.5 transition-transform"})]})]})]}),(0,t.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-5 gap-8",id:"contact-form",children:[(0,t.jsxs)("div",{className:"lg:col-span-3 bg-card border border-border rounded-2xl p-8 shadow-sm relative overflow-hidden opacity-0 animate-fade-in-up delay-100",children:[(0,t.jsx)("div",{className:"absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/5 to-transparent pointer-events-none"}),(0,t.jsx)("h3",{className:"text-2xl font-bold mb-2 relative",children:"Send us a message"}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground mb-6 relative",children:"We respond within 24 hours, guaranteed."}),e?(0,t.jsxs)("div",{className:"flex flex-col items-center justify-center py-16 text-center animate-fade-in",children:[(0,t.jsx)("div",{className:"w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4 transition-transform active:scale-95 duration-500 animate-in zoom-in spin-in-12",children:(0,t.jsx)(l.CheckCircle,{className:"h-8 w-8 text-accent"})}),(0,t.jsx)("h4",{className:"text-xl font-bold mb-2",children:"Message Sent!"}),(0,t.jsx)("p",{className:"text-muted-foreground",children:"We'll get back to you within 24 hours."})]}):(0,t.jsxs)("form",{onSubmit:f,className:"space-y-4 relative animate-fade-in",children:[(0,t.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[(0,t.jsx)("div",{className:"group",children:(0,t.jsx)("input",{type:"text",name:"name","aria-label":"Full Name",value:x.name,onChange:y,placeholder:"Full Name",required:!0,className:"w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all placeholder:text-muted-foreground/60"})}),(0,t.jsx)("div",{className:"group",children:(0,t.jsx)("input",{type:"email",name:"email","aria-label":"Email Address",value:x.email,onChange:y,placeholder:"Email Address",required:!0,className:"w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all placeholder:text-muted-foreground/60"})})]}),(0,t.jsxs)("select",{name:"service","aria-label":"Select a Service",value:x.service,onChange:y,className:"w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all",children:[(0,t.jsx)("option",{disabled:!0,children:"Select a Service"}),(0,t.jsx)("option",{children:"AI Automation"}),(0,t.jsx)("option",{children:"Chatbot Development"}),(0,t.jsx)("option",{children:"Workflow Automation"}),(0,t.jsx)("option",{children:"AI Marketing"}),(0,t.jsx)("option",{children:"CRM Solutions"}),(0,t.jsx)("option",{children:"Other"})]}),(0,t.jsx)("textarea",{name:"message","aria-label":"Your Message",value:x.message,onChange:y,placeholder:"Tell us about your project...",rows:4,required:!0,className:"w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all resize-none placeholder:text-muted-foreground/60"}),(0,t.jsxs)("button",{type:"submit",disabled:h,className:"btn-primary group w-full sm:w-auto shadow-lg shadow-primary/20 disabled:opacity-70 disabled:cursor-not-allowed transition-all active:scale-95",children:[h?"Sending...":"Send Message"," ",(0,t.jsx)(s.Send,{className:`ml-2 h-4 w-4 ${!h&&"group-hover:translate-x-0.5 transition-transform"}`})]})]})]}),(0,t.jsxs)("div",{className:"lg:col-span-2 space-y-4 opacity-0 animate-fade-in-up delay-200",children:[[{icon:o.Mail,label:"Email",value:"Hello@atulautomation.com",color:"text-primary",bg:"bg-primary/8",href:"mailto:Hello@atulautomation.com"},{icon:r.Phone,label:"WhatsApp",value:"+91 85188 24480",color:"text-emerald-500",bg:"bg-emerald-500/8",href:"https://wa.me/918518824480"},{icon:i,label:"Location",value:"India · Remote Worldwide",color:"text-blue-500",bg:"bg-blue-500/8",href:"#"}].map((e,a)=>{let s=e.icon;return(0,t.jsx)("a",{href:e.href,className:"block group bg-card border border-border rounded-2xl p-5 hover:border-primary/20 hover:shadow-lg transition-all duration-300",children:(0,t.jsxs)("div",{className:"flex items-center gap-4",children:[(0,t.jsx)("div",{className:`w-12 h-12 rounded-xl ${e.bg} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`,children:(0,t.jsx)(s,{className:`h-5 w-5 ${e.color}`})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"text-xs text-muted-foreground font-medium mb-0.5",children:e.label}),(0,t.jsx)("p",{className:"text-sm font-semibold group-hover:text-primary transition-colors",children:e.value})]})]})},a)}),(0,t.jsxs)("div",{className:"bg-card border border-border rounded-2xl p-6",children:[(0,t.jsx)("p",{className:"text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4",children:"Why trust us"}),(0,t.jsx)("div",{className:"grid grid-cols-2 gap-3",children:[{icon:c.Shield,label:"SSL Secured",color:"text-emerald-500"},{icon:u.Clock,label:"24h Response",color:"text-blue-500"},{icon:d.Sparkles,label:"Free Consult",color:"text-primary"},{icon:m.Award,label:"200+ Projects",color:"text-violet-500"}].map((e,a)=>(0,t.jsxs)("div",{className:"flex items-center gap-2 bg-muted/30 p-2.5 rounded-xl hover:bg-muted/50 transition-colors",children:[(0,t.jsx)(e.icon,{className:`h-3.5 w-3.5 ${e.color} shrink-0`}),(0,t.jsx)("span",{className:"text-xs font-medium",children:e.label})]},a))})]})]})]})]})]})}e.s(["Contact",()=>p],57841)},32499,e=>{"use strict";var t=e.i(43476),a=e.i(71645),s=e.i(10980),o=e.i(78716),r=e.i(78583),i=e.i(41240),n=e.i(55436),l=e.i(3116),d=e.i(70273),c=e.i(31343),u=e.i(63059),m=e.i(78917),p=e.i(87130),h=e.i(25652),g=e.i(47163),x=e.i(22016),b=e.i(14453);let f=[{id:"courses",label:"Courses",icon:s.BookOpen,color:"text-primary",bg:"bg-primary/10"},{id:"guides",label:"Guides",icon:r.FileText,color:"text-blue-500",bg:"bg-blue-500/10"},{id:"videos",label:"Videos",icon:o.Video,color:"text-rose-500",bg:"bg-rose-500/10"},{id:"prompts",label:"Prompts",icon:i.Lightbulb,color:"text-amber-500",bg:"bg-amber-500/10"}],y={courses:[{title:"AI Automation Fundamentals",desc:"Learn the basics of building intelligent workflows from scratch.",type:"Beginner",duration:"2h 15m",rating:4.8,difficulty:1,featured:!0},{title:"WhatsApp Bot Masterclass",desc:"Build & deploy a customer support bot on WhatsApp with 24/7 automation.",type:"Intermediate",duration:"4h 30m",rating:4.9,difficulty:3},{title:"Advanced Agent Pipelines",desc:"Complex multi-step AI agents using LangChain and AutoGen for deep tasks.",type:"Advanced",duration:"6h 00m",rating:5,difficulty:5,featured:!0},{title:"AI for Real Estate Agents",desc:"Specific workflows for lead qualification and automated property showings.",type:"Industry",duration:"3h 45m",rating:4.7,difficulty:2},{title:"SaaS Sales Automation",desc:"Automate your entire cold outreach and lead nurturing pipeline.",type:"Mastery",duration:"5h 20m",rating:4.9,difficulty:4},{title:"No-Code CRM Mastery",desc:"Master GoHighLevel and HubSpot integrations with AI modules.",type:"Intermediate",duration:"3h 10m",rating:4.6,difficulty:3}],guides:[{title:"Zapier vs Make: 2026 Guide",desc:"A deep dive into pricing, features, and when to use which platform.",type:"Comparison",duration:"15m read",rating:4.9,difficulty:2,featured:!0},{title:"AI Voice Agents Setup",desc:"How to setup Vapi or Retell to handle phone calls automatically.",type:"Technical",duration:"25m read",rating:4.8,difficulty:4},{title:"Data Security in AI",desc:"Ensuring your business data remains private while using LLMs.",type:"Security",duration:"10m read",rating:4.7,difficulty:3},{title:"The 'AI First' Office",desc:"Guide on redesigning your internal operations around automation.",type:"Strategy",duration:"20m read",rating:4.9,difficulty:2},{title:"Lead Magnet Blueprint",desc:"How to use AI to generate leads using free tools.",type:"Marketing",duration:"12m read",rating:4.6,difficulty:1}],videos:[{title:"Build a Bot in 10 Minutes",desc:"Live walkthrough of creating a support chatbot for a retail shop.",type:"Build",duration:"10:24",rating:4.9,difficulty:2,featured:!0},{title:"The Future of AI Agents",desc:"Keynote on how autonomous agents will run businesses by 2027.",type:"Insight",duration:"18:45",rating:5,difficulty:1},{title:"n8n Self-Hosting Guide",desc:"How to host your own automation platform for unlimited tasks.",type:"Advanced",duration:"22:15",rating:4.7,difficulty:5},{title:"ROI of AI Automation",desc:"Case studies of 3 Indian businesses that saved millions.",type:"Business",duration:"14:30",rating:4.8,difficulty:2},{title:"Claude vs GPT-4 for Business",desc:"Which model should you choose for your specific workflow?",type:"Review",duration:"11:05",rating:4.9,difficulty:2}],prompts:[{title:"Master Support Prompt Pack",desc:"Secret prompts we use to make chatbots sound human.",type:"Library",duration:"50+ Prompts",rating:4.9,difficulty:1,featured:!0},{title:"LinkedIn Content Generator",desc:"Prompts to create 30 days of viral posts in 5 minutes.",type:"Marketing",duration:"12 Prompts",rating:4.8,difficulty:2},{title:"Cold Outreach Templates",desc:"High-converting email and DM scripts for AI agencies.",type:"Sales",duration:"25 Prompts",rating:4.7,difficulty:2},{title:"SEO Content Brief Boilerplate",desc:"Generate perfect content briefs for your blog writers.",type:"SEO",duration:"5 Prompts",rating:4.8,difficulty:3},{title:"Lead Scraper Instructions",desc:"Commands to use with AI scrapers for targeted B2B leads.",type:"Tools",duration:"8 Prompts",rating:4.6,difficulty:4}]};function v({level:e}){return(0,t.jsx)("div",{className:"flex gap-1",children:[1,2,3,4,5].map(a=>(0,t.jsx)("div",{className:(0,g.cn)("w-1.5 h-1.5 rounded-full transition-colors",a<=e?"bg-primary":"bg-muted-foreground/20")},a))})}function w(){let[e,o]=(0,a.useState)("courses"),[r,i]=(0,a.useState)(""),w=(0,a.useMemo)(()=>{let t=y[e]||[];if(!r)return t;let a=r.toLowerCase();return t.filter(e=>e.title.toLowerCase().includes(a)||e.desc.toLowerCase().includes(a)||e.type.toLowerCase().includes(a))},[e,r]);return(0,t.jsxs)("section",{id:"resources",className:"section-padding bg-transparent relative overflow-hidden",children:[(0,t.jsx)("div",{className:"absolute top-0 right-0 w-1/3 h-1/3 bg-primary/5 blur-[120px] rounded-full pointer-events-none"}),(0,t.jsx)("div",{className:"absolute bottom-0 left-0 w-1/4 h-1/4 bg-blue-500/5 blur-[100px] rounded-full pointer-events-none"}),(0,t.jsxs)("div",{className:"container-custom relative z-10",children:[(0,t.jsxs)("div",{className:"max-w-3xl mx-auto text-center mb-16 opacity-0 animate-fade-in-up",children:[(0,t.jsxs)("p",{className:"section-badge mb-4",children:[(0,t.jsx)(s.BookOpen,{className:"h-3.5 w-3.5"})," Premium Learning"]}),(0,t.jsxs)("h2",{className:"text-4xl md:text-6xl font-bold mb-6",children:["The Automation ",(0,t.jsx)("span",{className:"text-gradient",children:"Knowledge Hub"})]}),(0,t.jsx)("p",{className:"text-muted-foreground text-lg mb-10 max-w-xl mx-auto",children:"A curated collection of resources designed to help you master AI automation, from beginner foundations to advanced agent orchestration."}),(0,t.jsxs)("div",{className:"max-w-lg mx-auto relative group",children:[(0,t.jsx)("div",{className:"absolute inset-y-0 left-4 flex items-center pointer-events-none",children:(0,t.jsx)(n.Search,{className:"h-4.5 w-4.5 text-muted-foreground group-focus-within:text-primary transition-colors"})}),(0,t.jsx)("input",{type:"text",placeholder:"Search resources, topics, or difficulty...",className:"w-full bg-card/50 backdrop-blur-sm border border-border group-hover:border-primary/30 focus:border-primary focus:ring-4 focus:ring-primary/10 rounded-2xl py-4 pl-12 pr-4 text-sm transition-all shadow-sm",value:r,onChange:e=>i(e.target.value)}),(0,t.jsx)("div",{className:"absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none",children:(0,t.jsx)("span",{className:"text-[10px] font-bold text-muted-foreground bg-muted px-1.5 py-0.5 rounded border border-border",children:"ESC"})})]})]}),(0,t.jsxs)("div",{className:"flex flex-col lg:flex-row items-center justify-between gap-8 mb-12",children:[(0,t.jsx)("div",{className:"flex flex-wrap justify-center gap-2 p-1.5 bg-muted/50 backdrop-blur-md rounded-2xl border border-border shadow-inner",children:f.map(a=>{let s=a.icon,r=e===a.id;return(0,t.jsxs)("button",{onClick:()=>o(a.id),className:(0,g.cn)("flex items-center gap-2.5 px-6 py-3 rounded-xl text-sm font-bold transition-all duration-300",r?"bg-card text-foreground shadow-sm ring-1 ring-primary/20 scale-[1.02]":"text-muted-foreground hover:text-foreground hover:bg-muted"),children:[(0,t.jsx)(s,{className:(0,g.cn)("h-4.5 w-4.5 transition-transform",r?(0,g.cn)(a.color,"scale-110"):"")}),a.label]},a.id)})}),(0,t.jsxs)("div",{className:"flex gap-6 items-center",children:[(0,t.jsxs)("div",{className:"flex flex-col items-end",children:[(0,t.jsx)("span",{className:"text-2xl font-bold text-primary",children:"50+"}),(0,t.jsx)("span",{className:"text-[10px] uppercase font-black tracking-widest text-muted-foreground",children:"Resources"})]}),(0,t.jsx)("div",{className:"h-10 w-px bg-border hidden sm:block"}),(0,t.jsxs)("div",{className:"flex flex-col items-end",children:[(0,t.jsx)("span",{className:"text-2xl font-bold text-blue-500",children:"4.9/5"}),(0,t.jsx)("span",{className:"text-[10px] uppercase font-black tracking-widest text-muted-foreground",children:"Avg Rating"})]})]})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in-up",children:w.length>0?w.map((a,s)=>{let o=f.find(t=>t.id===e);return(0,t.jsxs)("div",{className:(0,g.cn)("group bg-card/60 backdrop-blur-xl border border-border rounded-3xl p-7 hover:shadow-2xl hover:border-primary/40 transition-all duration-500 flex flex-col relative overflow-hidden",a.featured&&"ring-2 ring-primary/20 md:scale-[1.03] z-10 shadow-xl"),children:[a.featured&&(0,t.jsx)("div",{className:"absolute top-4 right-4 animate-pulse",children:(0,t.jsx)(h.TrendingUp,{className:"h-4 w-4 text-primary"})}),(0,t.jsxs)("div",{className:"flex items-center justify-between mb-6",children:[(0,t.jsx)("div",{className:(0,g.cn)("px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider",o.bg,o.color),children:a.type}),(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsxs)("div",{className:"flex items-center gap-1",children:[(0,t.jsx)(d.Star,{className:"h-3 w-3 text-amber-500 fill-amber-500"}),(0,t.jsx)("span",{className:"text-xs font-bold",children:a.rating})]}),(0,t.jsx)("div",{className:"h-3 w-px bg-border"}),(0,t.jsx)(v,{level:a.difficulty})]})]}),(0,t.jsxs)("div",{className:"flex-1",children:[(0,t.jsx)("h3",{className:"text-xl font-bold mb-3 group-hover:text-primary transition-colors line-clamp-2 leading-snug tracking-tight",children:a.title}),(0,t.jsxs)("p",{className:"text-sm text-muted-foreground line-clamp-3 leading-relaxed mb-6 italic opacity-85 group-hover:opacity-100 transition-opacity",children:['"',a.desc,'"']})]}),(0,t.jsxs)("div",{className:"flex items-center justify-between mt-auto pt-6 border-t border-border/50",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 text-muted-foreground",children:[(0,t.jsx)(l.Clock,{className:"h-3.5 w-3.5"}),(0,t.jsx)("span",{className:"text-xs font-medium uppercase tracking-tighter",children:a.duration})]}),"courses"===e||"guides"===e?(0,t.jsxs)(x.default,{href:`/courses/${(0,b.generateSlug)(a.title)}`,className:"flex items-center gap-2 px-4 py-2 rounded-xl bg-muted/60 text-xs font-bold ring-1 ring-border group-hover:bg-primary group-hover:text-white group-hover:ring-primary transition-all shadow-sm",children:[(0,t.jsx)(u.ChevronRight,{className:"h-3 w-3"}),"Read Guide"]}):(0,t.jsxs)("button",{className:"flex items-center gap-2 px-4 py-2 rounded-xl bg-muted/60 text-xs font-bold ring-1 ring-border group-hover:bg-primary group-hover:text-white group-hover:ring-primary transition-all shadow-sm",children:["videos"===e?(0,t.jsx)(c.Play,{className:"h-3 w-3"}):(0,t.jsx)(m.ExternalLink,{className:"h-3 w-3"}),"videos"===e?"Watch Now":"Get Prompts"]})]})]},s)}):(0,t.jsxs)("div",{className:"col-span-full py-20 text-center",children:[(0,t.jsx)("div",{className:"bg-muted w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-4",children:(0,t.jsx)(p.Filter,{className:"h-8 w-8 text-muted-foreground/40"})}),(0,t.jsx)("h3",{className:"text-xl font-bold mb-2",children:"No matching resources"}),(0,t.jsxs)("p",{className:"text-muted-foreground",children:['Try adjusting your search term for "',r,'"']}),(0,t.jsx)("button",{onClick:()=>i(""),className:"mt-4 text-primary font-bold text-sm hover:underline",children:"Clear all filters"})]})}),(0,t.jsx)("div",{className:"mt-20 text-center opacity-0 animate-fade-in-up delay-[400ms]",children:(0,t.jsxs)("div",{className:"p-8 rounded-3xl border border-dashed border-border bg-muted/20 flex flex-col md:flex-row items-center justify-between gap-6 max-w-4xl mx-auto",children:[(0,t.jsxs)("div",{className:"text-left",children:[(0,t.jsx)("h4",{className:"font-bold text-lg mb-1",children:"Want a custom learning path?"}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground",children:"Tell us your industry and we'll build a personalized automation roadmap for you."})]}),(0,t.jsxs)(x.default,{href:"/#contact",className:"btn-primary group whitespace-nowrap",children:["Build My Roadmap ",(0,t.jsx)(u.ChevronRight,{className:"ml-2 h-4 w-4 transition-transform group-hover:translate-x-1"})]})]})})]})]})}e.s(["DocsHub",()=>w])},51018,e=>{"use strict";var t=e.i(43476),a=e.i(71645),s=e.i(86311),o=e.i(83086),r=e.i(75254);let i=(0,r.default)("shopping-bag",[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]]),n=(0,r.default)("house",[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]]);var l=e.i(58472),d=e.i(31245),c=e.i(14764),u=e.i(31278);function m(){let[e,s]=(0,a.useState)([{role:"bot",content:"👋 Hi there! I'm your AI assistant. How can I help you automate your business today?"}]),[o,r]=(0,a.useState)(""),[i,n]=(0,a.useState)(!1),l=async()=>{o.trim()&&(s(e=>[...e,{role:"user",content:o}]),r(""),n(!0),setTimeout(()=>{n(!1),s(e=>[...e,{role:"bot",content:"That sounds like a great use case! I can set up a workflow to handle that automatically. Would you like to see a demo?"}])},1500))};return(0,t.jsxs)("div",{className:"flex flex-col h-[400px] border border-border rounded-xl overflow-hidden bg-background",children:[(0,t.jsxs)("div",{className:"bg-primary/10 p-4 border-b border-border flex items-center space-x-3",children:[(0,t.jsx)("div",{className:"h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center",children:(0,t.jsx)(d.Bot,{className:"h-6 w-6 text-primary"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h4",{className:"font-bold text-sm",children:"Automated Assistant"}),(0,t.jsxs)("div",{className:"flex items-center space-x-1",children:[(0,t.jsx)("span",{className:"h-2 w-2 rounded-full bg-green-500 animate-pulse"}),(0,t.jsx)("span",{className:"text-xs text-muted-foreground",children:"Online"})]})]})]}),(0,t.jsxs)("div",{className:"flex-1 overflow-y-auto p-4 space-y-4 bg-muted/5",children:[e.map((e,a)=>(0,t.jsx)("div",{className:`flex ${"user"===e.role?"justify-end":"justify-start"}`,children:(0,t.jsx)("div",{className:`max-w-[80%] p-3 rounded-lg text-sm ${"user"===e.role?"bg-primary text-primary-foreground rounded-br-none":"bg-card border border-border rounded-bl-none"}`,children:e.content})},a)),i&&(0,t.jsx)("div",{className:"flex justify-start",children:(0,t.jsx)("div",{className:"bg-card border border-border p-3 rounded-lg rounded-bl-none",children:(0,t.jsx)(u.Loader2,{className:"h-4 w-4 animate-spin text-muted-foreground"})})})]}),(0,t.jsxs)("div",{className:"p-3 border-t border-border bg-background flex space-x-2",children:[(0,t.jsx)("input",{"aria-label":"Type a message to WhatsApp bot",value:o,onChange:e=>r(e.target.value),onKeyDown:e=>"Enter"===e.key&&l(),placeholder:"Type a message...",className:"flex-1 bg-muted border-none rounded-full px-4 text-sm focus:ring-1 focus:ring-primary outline-none"}),(0,t.jsx)("button",{"aria-label":"Send WhatsApp message",onClick:l,className:"p-2 rounded-full bg-primary text-primary-foreground hover:opacity-90 transition-opacity",children:(0,t.jsx)(c.Send,{className:"h-4 w-4"})})]})]})}let p=(0,r.default)("copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);var h=e.i(43531);function g(){let[e,s]=(0,a.useState)(""),[r,i]=(0,a.useState)("instagram"),[n,l]=(0,a.useState)(""),[d,c]=(0,a.useState)(!1),[u,m]=(0,a.useState)(!1);return(0,t.jsxs)("div",{className:"h-[400px] border border-border rounded-xl  bg-background flex flex-col p-6",children:[(0,t.jsxs)("h3",{className:"font-bold text-lg mb-4 flex items-center",children:[(0,t.jsx)(o.Sparkles,{className:"h-5 w-5 text-accent mr-2"}),"Social Media Caption AI"]}),(0,t.jsxs)("div",{className:"space-y-4 flex-1",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"text-xs font-medium text-muted-foreground mb-1 block",children:"Topic / Image Desc"}),(0,t.jsx)("input",{"aria-label":"Topic or Image Description",value:e,onChange:e=>s(e.target.value),placeholder:"e.g. New AI product launch",className:"w-full p-2 rounded-lg bg-muted border border-border text-sm focus:border-primary outline-none"})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"text-xs font-medium text-muted-foreground mb-1 block",children:"Platform"}),(0,t.jsxs)("select",{"aria-label":"Social Media Platform",value:r,onChange:e=>i(e.target.value),className:"w-full p-2 rounded-lg bg-muted border border-border text-sm focus:border-primary outline-none",children:[(0,t.jsx)("option",{value:"instagram",children:"Instagram"}),(0,t.jsx)("option",{value:"twitter",children:"Twitter / X"}),(0,t.jsx)("option",{value:"linkedin",children:"LinkedIn"})]})]}),(0,t.jsx)("button",{onClick:()=>{c(!0),setTimeout(()=>{l(`🚀 Transform your business with AI today! 

We just launched a new tool that handles customer support 24/7. 

👉 Link in bio to try it out! 

#AI #Automation #GrowthHack #${r}`),c(!1)},1500)},disabled:d||!e,className:"w-full btn-primary py-2 text-sm disabled:opacity-50",children:d?"Generating...":"Generate Output"})]}),n&&(0,t.jsxs)("div",{className:"mt-4 p-3 bg-muted/50 rounded-lg border border-border relative group",children:[(0,t.jsx)("p",{className:"text-sm whitespace-pre-wrap",children:n}),(0,t.jsx)("button",{"aria-label":u?"Copied":"Copy to clipboard",onClick:()=>{navigator.clipboard.writeText(n),m(!0),setTimeout(()=>m(!1),2e3)},className:"absolute top-2 right-2 p-1.5 rounded-md bg-background border border-border hover:text-primary transition-colors opacity-0 group-hover:opacity-100",children:u?(0,t.jsx)(h.Check,{className:"h-3 w-3"}):(0,t.jsx)(p,{className:"h-3 w-3"})})]})]})}var x=e.i(1928);let b=(0,r.default)("package",[["path",{d:"M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",key:"1a0edw"}],["path",{d:"M12 22V12",key:"d0xqtd"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}]]),f=(0,r.default)("truck",[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]]),y=(0,r.default)("credit-card",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]);function v(){let e=[{icon:(0,t.jsx)(x.ShoppingCart,{}),label:"Order Received",color:"text-blue-500"},{icon:(0,t.jsx)(y,{}),label:"Payment Verified",color:"text-green-500"},{icon:(0,t.jsx)(b,{}),label:"Supplier Notified",color:"text-purple-500"},{icon:(0,t.jsx)(f,{}),label:"Shipped & Tracked",color:"text-orange-500"}];return(0,t.jsxs)("div",{className:"h-[400px] border border-border rounded-xl bg-background p-6 flex flex-col justify-center",children:[(0,t.jsx)("h3",{className:"font-bold text-lg mb-8 text-center opacity-0 animate-fade-in-up",children:"Automated Dropshipping Pipeline"}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)("div",{className:"absolute left-[20px] top-6 bottom-6 w-0.5 bg-border md:left-6 md:right-6 md:top-[20px] md:bottom-auto md:h-0.5 md:w-auto"}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-8",children:e.map((e,a)=>(0,t.jsxs)("div",{className:"relative flex md:flex-col items-center gap-4 md:gap-2 z-10 opacity-0 animate-fade-in-up",style:{animationDelay:`${200*a}ms`},children:[(0,t.jsx)("div",{className:`h-12 w-12 rounded-full bg-background border-2 border-primary flex items-center justify-center ${e.color} shadow-sm transition-transform hover:scale-110`,children:e.icon}),(0,t.jsx)("div",{className:"bg-card border border-border px-3 py-1.5 rounded-lg text-sm font-medium shadow-sm",children:e.label})]},a))})]}),(0,t.jsxs)("div",{className:"mt-8 p-4 bg-muted/30 rounded-lg text-xs font-mono text-muted-foreground opacity-0 animate-fade-in-up delay-700",children:[(0,t.jsxs)("div",{className:"flex justify-between items-center mb-1",children:[(0,t.jsx)("span",{children:"STATUS:"}),(0,t.jsx)("span",{className:"text-green-500 font-bold",children:"ACTIVE"})]}),(0,t.jsx)("p",{children:"> Monitoring Shopify Store for New Orders..."}),(0,t.jsx)("p",{children:"> Order #1024 detected. Processing..."}),(0,t.jsx)("p",{children:"> Supplier AliExpress notified via API."})]})]})}var w=e.i(43432),k=e.i(69638);function j(){let[e,s]=(0,a.useState)(0),o=()=>s(e=>e+1);return(0,t.jsxs)("div",{className:"h-[400px] border border-border rounded-xl bg-background p-6 relative overflow-hidden",children:[(0,t.jsx)("div",{className:"absolute top-0 right-0 p-4 opacity-5",children:(0,t.jsx)(n,{className:"h-32 w-32"})}),(0,t.jsx)("h3",{className:"font-bold text-lg mb-6 relative z-10",children:"Real Estate Lead Qualifier"}),(0,t.jsxs)("div",{className:"relative z-10 space-y-6",children:[0===e&&(0,t.jsxs)("div",{className:"space-y-4 animate-in fade-in slide-in-from-right-8 duration-500",children:[(0,t.jsx)("p",{className:"text-sm text-muted-foreground",children:"Lead form submission detected via Facebook Ads."}),(0,t.jsxs)("div",{className:"bg-card border border-border p-4 rounded-lg space-y-2",children:[(0,t.jsx)("div",{className:"h-2 w-1/3 bg-muted rounded"}),(0,t.jsx)("div",{className:"h-2 w-2/3 bg-muted rounded"})]}),(0,t.jsx)("button",{onClick:o,className:"btn-primary w-full text-sm py-2",children:"Simulate Incoming Lead"})]}),1===e&&(0,t.jsxs)("div",{className:"space-y-4 animate-in fade-in slide-in-from-right-8 duration-500",children:[(0,t.jsxs)("div",{className:"flex items-center space-x-3 text-green-600",children:[(0,t.jsx)(w.Phone,{className:"h-5 w-5"}),(0,t.jsx)("span",{className:"font-bold",children:"AI Calling Lead..."})]}),(0,t.jsx)("div",{className:"bg-muted p-3 rounded-lg text-sm italic",children:'"Hi, this is Sarah from Premier Homes. I saw you were interested in the downtown property..."'}),(0,t.jsx)("button",{onClick:o,className:"w-full py-2 bg-secondary text-white rounded-lg text-sm",children:"Lead Answers Call"})]}),2===e&&(0,t.jsxs)("div",{className:"space-y-4 animate-in fade-in slide-in-from-right-8 duration-500",children:[(0,t.jsxs)("div",{className:"flex items-center space-x-2 text-primary",children:[(0,t.jsx)(k.CheckCircle,{className:"h-6 w-6"}),(0,t.jsx)("span",{className:"font-bold text-lg",children:"Appointment Booked!"})]}),(0,t.jsxs)("div",{className:"bg-card border border-border p-4 rounded-lg",children:[(0,t.jsxs)("div",{className:"flex justify-between text-sm mb-2",children:[(0,t.jsx)("span",{className:"text-muted-foreground",children:"Date:"}),(0,t.jsx)("span",{className:"font-bold",children:"Tomorrow, 2:00 PM"})]}),(0,t.jsxs)("div",{className:"flex justify-between text-sm",children:[(0,t.jsx)("span",{className:"text-muted-foreground",children:"Agent:"}),(0,t.jsx)("span",{className:"font-bold",children:"Assigned to Mike"})]})]}),(0,t.jsx)("button",{onClick:()=>s(0),className:"text-xs text-muted-foreground hover:underline",children:"Reset Demo"})]})]})]})}var A=e.i(31343);function N(){let[e,s]=(0,a.useState)(`{
  "agent_type": "support",
  "tone": "empathetic",
  "rules": [
    "never_mention_competitors",
    "always_offer_refund_if_angry"
  ]
}`),[o,r]=(0,a.useState)("");return(0,t.jsxs)("div",{className:"h-[400px] border border-border rounded-xl bg-background flex flex-col overflow-hidden",children:[(0,t.jsxs)("div",{className:"bg-muted border-b border-border p-2 flex items-center justify-between",children:[(0,t.jsxs)("div",{className:"flex items-center space-x-2 px-2",children:[(0,t.jsx)(l.Code,{className:"h-4 w-4 text-muted-foreground"}),(0,t.jsx)("span",{className:"text-xs font-mono text-muted-foreground",children:"config.json"})]}),(0,t.jsxs)("button",{onClick:()=>{r("// Parsed Configuration...\n// Initializing Agent...\n>> Agent Ready: Support Bot v2.1\n>> Listening on port 8080")},className:"text-xs flex items-center bg-primary/10 text-primary px-2 py-1 rounded hover:bg-primary/20 transition-colors",children:[(0,t.jsx)(A.Play,{className:"h-3 w-3 mr-1"})," Run"]})]}),(0,t.jsxs)("div",{className:"flex-1 grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border",children:[(0,t.jsx)("textarea",{"aria-label":"JSON Configuration",value:e,onChange:e=>s(e.target.value),className:"w-full h-full p-4 bg-background font-mono text-xs resize-none outline-none text-foreground",spellCheck:"false"}),(0,t.jsx)("div",{className:"bg-muted/10 p-4 font-mono text-xs text-green-600 whitespace-pre-wrap",children:o||"// Output will appear here..."})]})]})}let C=[{id:"whatsapp",label:"WhatsApp Bot",icon:s.MessageSquare,color:"text-green-500",bg:"bg-green-500/10",ring:"ring-green-500/30"},{id:"social",label:"Social Media AI",icon:o.Sparkles,color:"text-pink-500",bg:"bg-pink-500/10",ring:"ring-pink-500/30"},{id:"dropshipping",label:"Dropshipping",icon:i,color:"text-blue-500",bg:"bg-blue-500/10",ring:"ring-blue-500/30"},{id:"realestate",label:"Real Estate",icon:n,color:"text-amber-500",bg:"bg-amber-500/10",ring:"ring-amber-500/30"},{id:"dev",label:"JSON Config",icon:l.Code,color:"text-violet-500",bg:"bg-violet-500/10",ring:"ring-violet-500/30"}];function I(){let[e,s]=(0,a.useState)("whatsapp");return(0,t.jsx)("section",{id:"modules-demo",className:"section-padding bg-muted/30",children:(0,t.jsxs)("div",{className:"container-custom",children:[(0,t.jsxs)("div",{className:"max-w-2xl mx-auto text-center mb-12 opacity-0 animate-fade-in-up",children:[(0,t.jsxs)("p",{className:"section-badge mb-4",children:[(0,t.jsx)(d.Bot,{className:"h-3.5 w-3.5"})," Try It Live"]}),(0,t.jsxs)("h2",{className:"text-3xl md:text-5xl font-bold mb-4",children:["Live ",(0,t.jsx)("span",{className:"text-primary",children:"AI Demos"})]}),(0,t.jsx)("p",{className:"text-muted-foreground text-lg",children:"Experience our AI agents in action. Select a module to test."})]}),(0,t.jsxs)("div",{className:"flex flex-col md:flex-row gap-5",children:[(0,t.jsx)("div",{className:"w-full md:w-64 flex flex-row md:flex-col overflow-x-auto md:overflow-visible gap-2 pb-3 md:pb-0 hide-scrollbar opacity-0 animate-fade-in-up delay-100",children:C.map(a=>{let o=a.icon,r=e===a.id;return(0,t.jsxs)("button",{onClick:()=>s(a.id),className:`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all whitespace-nowrap md:whitespace-normal w-full ${r?`bg-card border border-border shadow-sm ring-2 ${a.ring}`:"bg-transparent border border-transparent hover:bg-card hover:border-border"}`,children:[(0,t.jsx)("div",{className:`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${r?a.bg:"bg-muted"} transition-colors`,children:(0,t.jsx)(o,{className:`h-4 w-4 ${r?a.color:"text-muted-foreground"} transition-colors`})}),(0,t.jsx)("span",{className:r?"text-foreground font-semibold":"text-muted-foreground",children:a.label})]},a.id)})}),(0,t.jsxs)("div",{className:"flex-1 bg-card border border-border rounded-2xl p-6 md:p-8 min-h-[480px] opacity-0 animate-fade-in-up delay-200",children:["whatsapp"===e&&(0,t.jsx)(m,{}),"social"===e&&(0,t.jsx)(g,{}),"dropshipping"===e&&(0,t.jsx)(v,{}),"realestate"===e&&(0,t.jsx)(j,{}),"dev"===e&&(0,t.jsx)(N,{})]})]})]})})}e.s(["AIModules",()=>I],51018)},65402,e=>{"use strict";var t=e.i(43476),a=e.i(71645),s=e.i(72520),o=e.i(39312),r=e.i(64659),i=e.i(1928),n=e.i(86311),l=e.i(22258),d=e.i(75254);let c=(0,d.default)("pen-tool",[["path",{d:"M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z",key:"nt11vn"}],["path",{d:"m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18",key:"15qc1e"}],["path",{d:"m2.3 2.3 7.286 7.286",key:"1wuzzi"}],["circle",{cx:"11",cy:"11",r:"2",key:"xmgehs"}]]),u=(0,d.default)("arrow-right-left",[["path",{d:"m16 3 4 4-4 4",key:"1x1c3m"}],["path",{d:"M20 7H4",key:"zbl0bi"}],["path",{d:"m8 21-4-4 4-4",key:"h9nckh"}],["path",{d:"M4 17h16",key:"g4d7ey"}]]);var m=e.i(95468),p=e.i(3116),h=e.i(20278),g=e.i(40524),x=e.i(41202),b=e.i(63488),f=e.i(31245),y=e.i(58041),v=e.i(31091),w=e.i(55436);let k=[{title:"AI-Powered E-Commerce Assistant",desc:"Built a conversational commerce bot that increased sales by 180% for a fashion brand.",tags:["GPT-4","Shopify","WhatsApp"],gradient:"from-primary/10 via-primary/5 to-transparent",accent:"border-l-primary",accentColor:"text-primary",icon:(0,t.jsx)(i.ShoppingCart,{className:"h-5 w-5"}),challenge:"High cart abandonment rate (78%) and zero after-hours customer support.",solution:"Deployed a GPT-4 powered WhatsApp bot that engages customers post-browse, recommends products, and recovers abandoned carts automatically.",process:[{step:1,title:"Customer Browses Store",desc:"Shopify tracks browsing behavior, wishlist additions, and cart activity via pixel events.",icon:(0,t.jsx)(x.Globe,{className:"h-4 w-4"})},{step:2,title:"AI Triggers Engagement",desc:"If cart is abandoned for 30 min, the bot sends a personalized WhatsApp message.",icon:(0,t.jsx)(f.Bot,{className:"h-4 w-4"})},{step:3,title:"Conversational Selling",desc:"GPT-4 handles natural language queries — size guides, color options, and delivery estimates.",icon:(0,t.jsx)(n.MessageSquare,{className:"h-4 w-4"})},{step:4,title:"Checkout & Upsell",desc:"Bot sends secure Shopify checkout link with 1-click payment.",icon:(0,t.jsx)(i.ShoppingCart,{className:"h-4 w-4"})},{step:5,title:"Post-Purchase Nurture",desc:"Automated delivery tracking, review requests, and loyalty program enrollment.",icon:(0,t.jsx)(b.Mail,{className:"h-4 w-4"})}],channels:[{name:"WhatsApp Business API",role:"Primary interaction channel",icon:(0,t.jsx)(n.MessageSquare,{className:"h-4 w-4 text-green-500"})},{name:"Shopify Webhooks",role:"Real-time cart tracking",icon:(0,t.jsx)(i.ShoppingCart,{className:"h-4 w-4 text-blue-500"})},{name:"OpenAI GPT-4 API",role:"Product recommendations",icon:(0,t.jsx)(f.Bot,{className:"h-4 w-4 text-violet-500"})},{name:"Stripe",role:"Secure in-chat checkout",icon:(0,t.jsx)(m.CheckCircle2,{className:"h-4 w-4 text-primary"})}],metrics:[{value:"180%",label:"Sales Increase",color:"text-primary"},{value:"62%",label:"Cart Recovery",color:"text-emerald-500"},{value:"< 3s",label:"Response Time",color:"text-blue-500"},{value:"24/7",label:"Availability",color:"text-violet-500"}],timeline:"4 Weeks",industry:"Fashion E-Commerce"},{title:"Multi-Channel CRM Automation",desc:"Unified customer data from 6 platforms into a single intelligent pipeline.",tags:["HubSpot","Zapier","Webhooks"],gradient:"from-blue-500/10 via-blue-500/5 to-transparent",accent:"border-l-blue-500",accentColor:"text-blue-500",icon:(0,t.jsx)(y.Database,{className:"h-5 w-5"}),challenge:"Customer data was scattered across 6 platforms causing duplicate entries and missed follow-ups.",solution:"Built a centralized automation hub that syncs all channels into HubSpot CRM in real-time, with AI-powered lead scoring.",process:[{step:1,title:"Lead Capture",desc:"Incoming leads from website forms, WhatsApp, and DM are captured by Zapier.",icon:(0,t.jsx)(h.Target,{className:"h-4 w-4"})},{step:2,title:"De-duplication",desc:"AI checks for existing contacts and merges duplicates.",icon:(0,t.jsx)(y.Database,{className:"h-4 w-4"})},{step:3,title:"Lead Scoring",desc:"Each lead is scored (1-100) based on engagement and intent.",icon:(0,t.jsx)(l.BarChart3,{className:"h-4 w-4"})},{step:4,title:"Smart Routing",desc:"Hot leads get instant Slack alerts to sales. Others get nurtured.",icon:(0,t.jsx)(u,{className:"h-4 w-4"})},{step:5,title:"Pipeline Automation",desc:"Deal stages flow through HubSpot automatically.",icon:(0,t.jsx)(g.Workflow,{className:"h-4 w-4"})}],channels:[{name:"HubSpot CRM",role:"Central database",icon:(0,t.jsx)(y.Database,{className:"h-4 w-4 text-orange-500"})},{name:"Zapier",role:"Data middleware",icon:(0,t.jsx)(g.Workflow,{className:"h-4 w-4 text-blue-500"})},{name:"Slack",role:"Real-time alerts",icon:(0,t.jsx)(n.MessageSquare,{className:"h-4 w-4 text-purple-500"})},{name:"Calendly",role:"Auto-scheduling",icon:(0,t.jsx)(p.Clock,{className:"h-4 w-4 text-green-500"})}],metrics:[{value:"6→1",label:"Platforms Unified",color:"text-blue-500"},{value:"45%",label:"Faster Follow-up",color:"text-emerald-500"},{value:"0",label:"Duplicate Leads",color:"text-primary"},{value:"3.2x",label:"Conversion Rate",color:"text-violet-500"}],timeline:"6 Weeks",industry:"B2B SaaS"},{title:"Real Estate Lead Qualifier",desc:"AI agent that qualifies leads from Facebook Ads and schedules property tours automatically.",tags:["Meta Ads","AI Agent","Calendar"],gradient:"from-violet-500/10 via-violet-500/5 to-transparent",accent:"border-l-violet-500",accentColor:"text-violet-500",icon:(0,t.jsx)(h.Target,{className:"h-5 w-5"}),challenge:"Agency spending heavily on ads but sales team wasting 70% of time on unqualified leads.",solution:"Deployed an AI qualification funnel that engages ad respondents, scores them, and books tours for hot prospects.",process:[{step:1,title:"Ad Click Engagement",desc:"Clicks on ads trigger instant AI greeting on WhatsApp.",icon:(0,t.jsx)(v.Megaphone,{className:"h-4 w-4"})},{step:2,title:"Smart Qualification",desc:"Bot asks budget, location, and timeline in natural language.",icon:(0,t.jsx)(f.Bot,{className:"h-4 w-4"})},{step:3,title:"AI Lead Scoring",desc:"Leads scored Hot/Warm/Cold based on answers.",icon:(0,t.jsx)(l.BarChart3,{className:"h-4 w-4"})},{step:4,title:"Auto Tour Booking",desc:"Hot leads get Calendly link. Agent gets prep sheet.",icon:(0,t.jsx)(p.Clock,{className:"h-4 w-4"})},{step:5,title:"Nurture",desc:"Warm leads listed in drip campaign. Cold leads retargeted.",icon:(0,t.jsx)(b.Mail,{className:"h-4 w-4"})}],channels:[{name:"Meta Ads",role:"Lead generation",icon:(0,t.jsx)(v.Megaphone,{className:"h-4 w-4 text-blue-600"})},{name:"WhatsApp",role:"Conversational qualification",icon:(0,t.jsx)(n.MessageSquare,{className:"h-4 w-4 text-green-500"})},{name:"Google Calendar",role:"Tour scheduling",icon:(0,t.jsx)(p.Clock,{className:"h-4 w-4 text-blue-500"})},{name:"Google Sheets",role:"Performance reporting",icon:(0,t.jsx)(l.BarChart3,{className:"h-4 w-4 text-emerald-500"})}],metrics:[{value:"34%",label:"Qualified Leads",color:"text-violet-500"},{value:"< 30s",label:"First Response",color:"text-emerald-500"},{value:"4.5x",label:"ROI on Ad Spend",color:"text-primary"},{value:"70%",label:"Time Saved",color:"text-blue-500"}],timeline:"3 Weeks",industry:"Real Estate"},{title:"Content Factory Pipeline",desc:"Automated blog writing, SEO optimization, and social media distribution.",tags:["Claude","WordPress","Buffer"],gradient:"from-emerald-500/10 via-emerald-500/5 to-transparent",accent:"border-l-emerald-500",accentColor:"text-emerald-500",icon:(0,t.jsx)(c,{className:"h-5 w-5"}),challenge:"Manual publishing was inconsistent and time-consuming (4+ hours per article).",solution:"Built an end-to-end pipeline: AI researches, writes SEO articles, publishes to WP, and schedules social posts.",process:[{step:1,title:"Topic Research",desc:"AI scans trends to identify high-opportunity topics.",icon:(0,t.jsx)(w.Search,{className:"h-4 w-4"})},{step:2,title:"Content Generation",desc:"Claude writes SEO-optimized draft with internal links.",icon:(0,t.jsx)(c,{className:"h-4 w-4"})},{step:3,title:"Optimization",desc:"Automated checks for readability and keyword density.",icon:(0,t.jsx)(l.BarChart3,{className:"h-4 w-4"})},{step:4,title:"Publishing",desc:"Auto-publish to WordPress with images and tags.",icon:(0,t.jsx)(x.Globe,{className:"h-4 w-4"})},{step:5,title:"Distribution",desc:"Buffer schedules posts for Twitter, LinkedIn, etc.",icon:(0,t.jsx)(v.Megaphone,{className:"h-4 w-4"})}],channels:[{name:"Claude AI",role:"Content generation",icon:(0,t.jsx)(f.Bot,{className:"h-4 w-4 text-violet-500"})},{name:"WordPress",role:"CMS publishing",icon:(0,t.jsx)(x.Globe,{className:"h-4 w-4 text-blue-500"})},{name:"Buffer",role:"Social distribution",icon:(0,t.jsx)(v.Megaphone,{className:"h-4 w-4 text-orange-500"})},{name:"Search Console",role:"Indexing & tracking",icon:(0,t.jsx)(w.Search,{className:"h-4 w-4 text-green-500"})}],metrics:[{value:"15",label:"Articles/Week",color:"text-emerald-500"},{value:"85%",label:"Time Saved",color:"text-primary"},{value:"320%",label:"Organic Traffic",color:"text-blue-500"},{value:"#1",label:"Rankings",color:"text-violet-500"}],timeline:"5 Weeks",industry:"Digital Media"}];function j(){let[e,i]=(0,a.useState)(null);return(0,t.jsxs)("section",{id:"projects",className:"section-padding bg-transparent relative",children:[(0,t.jsx)("div",{className:"absolute top-0 left-1/2 -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent rounded-full"}),(0,t.jsxs)("div",{className:"container-custom",children:[(0,t.jsxs)("div",{className:"max-w-2xl mx-auto text-center mb-16 opacity-0 animate-fade-in-up",children:[(0,t.jsxs)("p",{className:"section-badge mb-4",children:[(0,t.jsx)(o.Zap,{className:"h-3.5 w-3.5"})," Our Work"]}),(0,t.jsxs)("h2",{className:"text-3xl md:text-5xl font-bold mb-4",children:["Featured ",(0,t.jsx)("span",{className:"text-primary",children:"Projects"})]}),(0,t.jsx)("p",{className:"text-muted-foreground text-lg",children:"Real results from real automation deployments. Click to explore."})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-5",children:k.map((a,n)=>{let l=e===n;return(0,t.jsxs)("div",{className:`bg-card border border-border rounded-2xl overflow-hidden transition-all duration-300 relative border-l-[3px] opacity-0 animate-fade-in-up delay-100 ${a.accent} ${l?"shadow-2xl md:col-span-2 border-primary/30":"hover:shadow-xl hover:border-primary/20 cursor-pointer"}`,children:[(0,t.jsx)("div",{className:`absolute inset-0 bg-gradient-to-br ${a.gradient} ${l?"opacity-100":"opacity-0 group-hover:opacity-100"} transition-opacity duration-500 pointer-events-none`}),(0,t.jsxs)("div",{className:"relative z-10 p-7 cursor-pointer group",onClick:()=>{i(e===n?null:n)},children:[(0,t.jsxs)("div",{className:"flex items-start justify-between mb-4",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("div",{className:`w-10 h-10 rounded-xl bg-muted/70 flex items-center justify-center ${a.accentColor} shrink-0`,children:a.icon}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:`text-lg font-bold leading-tight transition-colors ${l?a.accentColor:"group-hover:text-primary"}`,children:a.title}),(0,t.jsxs)("div",{className:"flex items-center gap-2 mt-1",children:[(0,t.jsx)("span",{className:"text-[10px] font-semibold text-muted-foreground bg-muted/50 px-2 py-0.5 rounded",children:a.industry}),(0,t.jsxs)("span",{className:"text-[10px] text-muted-foreground",children:["· ",a.timeline]})]})]})]}),(0,t.jsx)("div",{className:`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ${l?"bg-primary/10 text-primary rotate-180":"bg-muted/50 text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary"}`,children:(0,t.jsx)(r.ChevronDown,{className:"h-4 w-4"})})]}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground leading-relaxed mb-4",children:a.desc}),(0,t.jsxs)("div",{className:"flex flex-wrap gap-2",children:[a.tags.map((e,a)=>(0,t.jsx)("span",{className:"text-[11px] font-semibold px-3 py-1 rounded-full bg-muted/70 text-muted-foreground border border-border/50",children:e},a)),!l&&(0,t.jsxs)("span",{className:`text-[11px] font-semibold px-3 py-1 rounded-full ${a.accentColor} bg-muted/50 border border-border/50 flex items-center gap-1`,children:["Click to explore ",(0,t.jsx)(s.ArrowRight,{className:"h-3 w-3"})]})]})]}),l&&(0,t.jsx)("div",{className:"relative z-10 animate-fade-in-up",children:(0,t.jsxs)("div",{className:"px-7 pb-8 space-y-8",children:[(0,t.jsx)("div",{className:"w-full h-px bg-gradient-to-r from-transparent via-border to-transparent"}),(0,t.jsx)("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-3",children:a.metrics.map((e,a)=>(0,t.jsxs)("div",{className:"text-center py-4 rounded-xl bg-muted/40 border border-border/50",children:[(0,t.jsx)("p",{className:`text-xl font-bold ${e.color}`,children:e.value}),(0,t.jsx)("p",{className:"text-[11px] text-muted-foreground font-medium mt-0.5",children:e.label})]},a))}),(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("div",{className:"bg-red-500/5 border border-red-500/15 rounded-xl p-5",children:[(0,t.jsx)("p",{className:"text-xs font-bold text-red-500 uppercase tracking-wider mb-2",children:"⚡ The Challenge"}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground leading-relaxed",children:a.challenge})]}),(0,t.jsxs)("div",{className:"bg-emerald-500/5 border border-emerald-500/15 rounded-xl p-5",children:[(0,t.jsx)("p",{className:"text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2",children:"✅ Our Solution"}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground leading-relaxed",children:a.solution})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("h4",{className:"text-sm font-bold uppercase tracking-wider text-muted-foreground mb-5 flex items-center gap-2",children:[(0,t.jsx)(g.Workflow,{className:"h-4 w-4 text-primary"})," How It Works"]}),(0,t.jsx)("div",{className:"space-y-3",children:a.process.map((e,s)=>(0,t.jsxs)("div",{className:"flex items-start gap-4 group/step",children:[(0,t.jsxs)("div",{className:"flex flex-col items-center shrink-0",children:[(0,t.jsx)("div",{className:`w-9 h-9 rounded-xl border-2 border-border flex items-center justify-center ${a.accentColor} bg-card group-hover/step:border-primary/40 transition-colors`,children:e.icon}),s<a.process.length-1&&(0,t.jsx)("div",{className:"w-px h-6 bg-gradient-to-b from-border to-transparent mt-1"})]}),(0,t.jsxs)("div",{className:"flex-1 pb-2",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 mb-1",children:[(0,t.jsxs)("span",{className:`text-[10px] font-bold ${a.accentColor} bg-muted/50 px-1.5 py-0.5 rounded`,children:["STEP ",e.step]}),(0,t.jsx)("h5",{className:"text-sm font-bold text-foreground",children:e.title})]}),(0,t.jsx)("p",{className:"text-xs text-muted-foreground leading-relaxed",children:e.desc})]})]},s))})]}),(0,t.jsxs)("div",{children:[(0,t.jsxs)("h4",{className:"text-sm font-bold uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2",children:[(0,t.jsx)(o.Zap,{className:"h-4 w-4 text-primary"})," Channels & Tools Used"]}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3",children:a.channels.map((e,a)=>(0,t.jsxs)("div",{className:"flex items-start gap-3 p-4 rounded-xl bg-muted/30 border border-border/50 hover:border-border transition-colors",children:[(0,t.jsx)("div",{className:"w-9 h-9 rounded-lg bg-card border border-border flex items-center justify-center shrink-0 shadow-sm",children:e.icon}),(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"text-sm font-semibold text-foreground",children:e.name}),(0,t.jsx)("p",{className:"text-xs text-muted-foreground leading-relaxed",children:e.role})]})]},a))})]}),(0,t.jsxs)("div",{className:"flex flex-col sm:flex-row items-center gap-3 pt-4 border-t border-border/50",children:[(0,t.jsxs)("a",{href:"#contact",className:"btn-primary group text-sm",children:["Want Similar Results? ",(0,t.jsx)(s.ArrowRight,{className:"ml-2 h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform"})]}),(0,t.jsxs)("span",{className:"text-xs text-muted-foreground flex items-center gap-1.5",children:[(0,t.jsx)(p.Clock,{className:"h-3 w-3"})," Delivered in ",a.timeline," · ",a.industry]})]})]})})]},n)})})]})]})}e.s(["FeaturedProjects",()=>j],65402)},52866,e=>{"use strict";var t=e.i(43476),a=e.i(72520),s=e.i(10980),o=e.i(3116),r=e.i(75254);let i=(0,r.default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);var n=e.i(31245),l=e.i(39312),d=e.i(12426),c=e.i(61911);let u=(0,r.default)("wrench",[["path",{d:"M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",key:"1ngwbx"}]]);var m=e.i(55711),p=e.i(31091),h=e.i(22258),g=e.i(22016);let x=[{slug:"how-ai-chatbots-save-businesses-40-percent-support-costs",title:"How AI Chatbots Save Businesses 40% on Customer Support Costs",excerpt:"Discover how intelligent AI chatbots are transforming customer support — reducing costs by 40% while providing 24/7 instant responses that customers love.",content:`
## The Customer Support Crisis

Every business faces the same challenge: customers expect instant, 24/7 support, but hiring round-the-clock human agents is expensive. The average cost of a single customer service interaction is **₹500-800** for phone support and **₹200-400** for live chat.

**AI chatbots change the equation entirely.**

## How AI Chatbots Reduce Costs by 40%

### 1. Handle 80% of Queries Automatically
Most customer queries fall into predictable categories — order status, returns, pricing, FAQs. AI chatbots powered by GPT-4 and Claude can handle these instantly without human intervention.

### 2. 24/7 Availability Without Overtime
Unlike human agents, AI chatbots never sleep, never take breaks, and never call in sick. They provide consistent, high-quality support at 3 AM just as well as 3 PM.

### 3. Scale Instantly During Peak Hours
During sales events or product launches, support volume can spike 10x. AI chatbots scale instantly — no hiring, no training, no waiting.

### 4. Reduce Average Handle Time
AI chatbots resolve queries in **under 30 seconds** on average, compared to **8-12 minutes** for human agents. This means fewer support tickets and faster resolution.

## Real Results from Our Clients

| Metric | Before AI | After AI | Improvement |
|--------|-----------|----------|-------------|
| Avg. Response Time | 4 hours | 12 seconds | 99.9% faster |
| Support Cost/Month | ₹2,50,000 | ₹1,50,000 | 40% reduction |
| Customer Satisfaction | 72% | 91% | +19 points |
| Tickets Resolved/Day | 150 | 400 | 2.7x more |

## Getting Started with AI Chatbots

At **Atul Automation**, we build custom AI chatbots tailored to your business. Our chatbots:

- **Learn from your data** — product catalogs, FAQs, past conversations
- **Speak naturally** — powered by GPT-4 with custom personality
- **Integrate seamlessly** — WhatsApp, website, Instagram, Facebook
- **Hand off intelligently** — escalate complex issues to human agents

## The Bottom Line

AI chatbots aren't just a cost-saving tool — they're a **competitive advantage**. Businesses that deploy AI support today are setting themselves up for success tomorrow.

**Ready to reduce your support costs by 40%?** [Contact us](/contact) for a free consultation.
        `,coverImage:"/blog/chatbot-premium.png",category:"AI Chatbots",author:"Atul Automation",date:"2026-02-25",readTime:"5 min read",tags:["AI Chatbots","Customer Support","Cost Reduction","Automation"]},{slug:"5-workflow-automations-every-small-business-needs",title:"5 Workflow Automations Every Small Business Needs in 2026",excerpt:"Stop wasting hours on repetitive tasks. These 5 essential workflow automations will save your team 15+ hours per week and eliminate human errors.",content:`
## Why Automation Matters for Small Businesses

Small businesses waste an average of **23 hours per week** on repetitive manual tasks. That's nearly 3 full working days lost to data entry, follow-ups, and copy-pasting between tools.

Here are the **5 most impactful workflow automations** you should implement today.

## 1. Lead Capture → CRM → Auto-Response

**The Problem:** A lead fills out your contact form. You check it 6 hours later. By then, they've already contacted your competitor.

**The Automation:**
- Lead submits form → Instantly added to CRM
- AI scores the lead quality (hot/warm/cold)
- Personalized email sent within 60 seconds
- Sales team notified on WhatsApp/Slack
- Follow-up sequence triggered automatically

**Time Saved:** 5 hours/week

## 2. Invoice Generation & Follow-up

**The Problem:** Manually creating invoices, sending them, tracking payments, and following up on overdue ones.

**The Automation:**
- Project marked complete → Invoice auto-generated
- Sent to client via email with payment link
- Payment reminders at Day 3, Day 7, Day 14
- Payment received → Receipt sent + accounting updated

**Time Saved:** 3 hours/week

## 3. Social Media Content Pipeline

**The Problem:** Scrambling to create and post content across 4-5 platforms daily.

**The Automation:**
- AI generates content ideas based on trending topics
- Draft created and scheduled across platforms
- Auto-resize images for each platform
- Engagement analytics collected automatically
- Best-performing content repurposed

**Time Saved:** 4 hours/week

## 4. Customer Onboarding Sequence

**The Problem:** Manually sending welcome emails, setup guides, and check-in messages to new customers.

**The Automation:**
- New customer signed up → Welcome email with setup guide
- Day 2: Video tutorial sent
- Day 5: Check-in message asking if they need help
- Day 14: Feature highlight email
- Day 30: Feedback request + review link

**Time Saved:** 2 hours/week

## 5. Report Generation & Analytics

**The Problem:** Spending hours compiling data from different tools into weekly/monthly reports.

**The Automation:**
- Data pulled from Google Analytics, CRM, social media
- AI generates insights and trends
- Beautiful report created automatically
- Sent to stakeholders every Monday morning

**Time Saved:** 3 hours/week

## Total Impact

| Automation | Weekly Time Saved |
|-----------|-------------------|
| Lead Capture Pipeline | 5 hours |
| Invoice Automation | 3 hours |
| Social Media Pipeline | 4 hours |
| Customer Onboarding | 2 hours |
| Report Generation | 3 hours |
| **Total** | **17 hours/week** |

That's **17 hours per week** — or **68 hours per month** — returned to your team for high-value work.

## How to Get Started

You don't need to build these from scratch. At **Atul Automation**, we set up all 5 automations for your business in under 2 weeks, using tools like Make, Zapier, n8n, and custom APIs.

**[Book a free strategy call](#contact)** and let's automate your business.
        `,coverImage:"/blog/workflow-premium.png",category:"Workflow Automation",author:"Atul Automation",date:"2026-02-23",readTime:"7 min read",tags:["Workflow","Small Business","Productivity","Automation"]},{slug:"ai-marketing-3x-leads-automation",title:"AI Marketing: How to 3X Your Leads with Intelligent Automation",excerpt:"Learn how AI-powered marketing automation can triple your lead generation while cutting your ad spend. Real strategies that work in 2026.",content:`
## The New Era of AI Marketing

Traditional digital marketing is dead. Running the same Google Ads and Facebook campaigns as everyone else won't cut it anymore. **AI-powered marketing** is the new competitive edge.

## What is AI Marketing?

AI marketing combines machine learning, natural language processing, and automation to:

- **Predict** which leads are most likely to convert
- **Personalize** messaging for each individual prospect
- **Optimize** ad spend in real-time based on performance
- **Generate** high-converting copy and creatives automatically

## 5 AI Marketing Strategies to 3X Your Leads

### 1. AI-Powered Ad Creative Generation

Instead of A/B testing 3-4 ad variations, AI generates **50+ variations** and tests them simultaneously. The best performers get more budget automatically.

**Result:** 40% lower cost-per-lead on average.

### 2. Predictive Lead Scoring

Not all leads are equal. AI analyzes behavior patterns to score leads:
- **Hot leads (90+):** Immediate call from sales
- **Warm leads (60-89):** Nurture sequence activated
- **Cold leads (<60):** Long-term drip campaign

**Result:** Sales team focuses on leads 3x more likely to convert.

### 3. Dynamic Email Personalization

AI writes personalized email subject lines, body copy, and CTAs based on:
- The recipient's industry
- Their interaction history
- Time zone and optimal send time
- Content they've engaged with

**Result:** 65% higher open rates, 3x click-through rates.

### 4. Chatbot Lead Qualification

Instead of generic contact forms, AI chatbots engage visitors in conversation:
- Qualify their needs in real-time
- Book meetings directly
- Provide instant quotes
- Collect rich data for personalization

**Result:** 2.5x more qualified leads captured.

### 5. Content Marketing on Autopilot

AI helps create SEO-optimized blog posts, social media content, and video scripts:
- Identifies trending topics in your niche
- Generates draft content for human review
- Optimizes for keywords and search intent
- Schedules across all platforms

**Result:** 10x content output with same team size.

## The Numbers Don't Lie

Companies using AI marketing automation see:

- **300% increase** in lead generation
- **40% reduction** in cost-per-acquisition  
- **65% improvement** in email engagement
- **2.5x higher** conversion rates

## Start Your AI Marketing Journey

At **Atul Automation**, we implement AI marketing systems that deliver measurable results. From ad optimization to lead nurturing, we handle the entire pipeline.

**[Get your free AI marketing strategy](#contact)** — no obligation, just actionable insights.
        `,coverImage:"https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&q=80&w=800",category:"AI Marketing",author:"Atul Automation",date:"2026-02-20",readTime:"6 min read",tags:["AI Marketing","Lead Generation","Digital Marketing","ROI"]},{slug:"whatsapp-automation-complete-guide-2026",title:"WhatsApp Automation: The Complete Guide for Business in 2026",excerpt:"Learn how to automate WhatsApp for lead generation, customer support, and sales. Step-by-step guide with real examples from Indian businesses.",content:`
## Why WhatsApp Automation?

With **500 million+ users in India**, WhatsApp is the #1 communication channel. Yet most businesses still reply manually. **WhatsApp automation** changes everything.

## What Can You Automate on WhatsApp?

### 1. Instant Lead Response

When someone messages your business number, an AI chatbot responds **within 3 seconds** — even at 2 AM.

- Greet the customer by name
- Ask qualifying questions (budget, timeline, requirements)
- Share relevant product/service info
- Book a call or meeting automatically

**Impact:** Businesses that respond within 5 minutes are **21x more likely** to convert a lead.

### 2. Order Updates & Tracking

For e-commerce and service businesses:
- Order confirmation with details
- Shipping updates with tracking link
- Delivery confirmation
- Feedback request after delivery

No more "where is my order?" calls.

### 3. Appointment Reminders

For clinics, salons, consultants:
- Appointment confirmation when booked
- Reminder 24 hours before
- Reminder 1 hour before
- Easy rescheduling via chat
- Post-appointment follow-up

**Result:** 40% reduction in no-shows. See our [healthcare automation](/industries/ai-automation-for-healthcare) case study.

### 4. Broadcast Campaigns

Send personalized bulk messages:
- New product launches
- Festival offers and discounts
- Restock notifications
- Event invitations

**Open rate:** 98% (vs 20% for email).

## Tools for WhatsApp Automation

| Tool | Best For | Pricing |
|------|----------|---------|
| WhatsApp Business API | Large businesses | Pay per conversation |
| WATI | SMBs, team inbox | From ₹2,500/month |
| AiSensy | Indian businesses | From ₹999/month |
| Custom Bot (Our Specialty) | Full control | Custom pricing |

## Getting Started

At **Atul Automation**, we build custom WhatsApp bots that:
- Integrate with your CRM and inventory
- Handle multiple languages (Hindi + English)
- Process payments via UPI links
- Escalate to human agents when needed

**[Get your WhatsApp bot →](/blog/how-ai-chatbots-save-businesses-40-percent-support-costs)** or **[check our ROI calculator](/tools/roi-calculator)** to see your potential savings.
        `,coverImage:"https://images.unsplash.com/photo-1620712943543-bcc4628c925d?auto=format&fit=crop&q=80&w=800",category:"WhatsApp",author:"Atul Automation",date:"2026-02-18",readTime:"8 min read",tags:["WhatsApp","Chatbot","Business Automation","Lead Generation"]},{slug:"ai-crm-vs-manual-crm-comparison",title:"AI-Powered CRM vs Manual CRM: Which Should You Choose?",excerpt:"A detailed comparison of AI-powered CRM systems versus traditional manual CRM. See why businesses switching to AI CRM see 3x better conversion rates.",content:`
## The CRM Dilemma

Every business needs a CRM. But in 2026, the question isn't **whether** to use a CRM — it's whether your CRM should be **AI-powered**.

## Manual CRM: The Old Way

Traditional CRM involves:
- Manually entering lead information
- Creating follow-up reminders yourself
- Writing personalized emails one by one
- Guessing which leads are hot
- Building reports in spreadsheets

**Average time spent:** 6-8 hours/week per salesperson on CRM tasks.

## AI-Powered CRM: The New Way

AI CRM automates the grunt work:
- **Auto-capture leads** from website, WhatsApp, email, social
- **Smart scoring** — AI predicts which leads will convert
- **Auto follow-up** — Personalized messages sent automatically
- **Conversation intelligence** — AI analyzes call transcripts
- **Predictive analytics** — Forecast revenue accurately

## Head-to-Head Comparison

| Feature | Manual CRM | AI CRM |
|---------|-----------|--------|
| Lead Entry | Manual typing | Auto-captured |
| Lead Scoring | Gut feeling | Data-driven AI |
| Follow-ups | Manual reminders | Automated sequences |
| Email Personalization | Write each one | AI-generated |
| Reports | Manual spreadsheets | Real-time dashboards |
| Time per Lead | 15-20 minutes | 2-3 minutes |
| Conversion Rate | 2-5% | 8-15% |

## Real Impact Numbers

Businesses that switch to AI CRM see:
- **3x improvement** in lead conversion rates
- **65% reduction** in time spent on admin tasks
- **40% faster** sales cycle
- **90% fewer** missed follow-ups

## When to Choose Manual CRM

Manual CRM might be fine if:
- You have fewer than 20 leads per month
- Your sales cycle is simple (1-2 touchpoints)
- You're a solopreneur with no team

## When to Choose AI CRM

Switch to AI CRM when:
- You get 50+ leads per month
- You have a sales team of 2+ people
- Your sales cycle involves multiple touchpoints
- You're losing deals due to slow follow-up

## Our Recommendation

For most growing businesses, **AI CRM is a no-brainer**. The time savings alone justify the investment within the first month.

At **Atul Automation**, we set up [AI-powered CRM systems](/capabilities/crm) that integrate with your existing tools. Check our [workflow automation guide](/blog/5-workflow-automations-every-small-business-needs) for more ideas.

**[Get a free CRM audit →](/#contact)**
        `,coverImage:"https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800",category:"CRM",author:"Atul Automation",date:"2026-02-15",readTime:"6 min read",tags:["CRM","AI CRM","Sales Automation","Lead Management"]},{slug:"n8n-vs-make-vs-zapier-which-automation-tool",title:"n8n vs Make vs Zapier: Which Automation Tool is Best in 2026?",excerpt:"A comprehensive comparison of the top 3 workflow automation platforms. Features, pricing, pros & cons — everything you need to decide.",content:`
## The Big Three of Automation

If you're looking to automate workflows without coding, three platforms dominate: **n8n**, **Make** (formerly Integromat), and **Zapier**. But which one should you choose?

## Quick Overview

### Zapier
- **Best for:** Beginners and simple automations
- **Pricing:** Starts at $19.99/month (750 tasks)
- **Integrations:** 6,000+
- **Learning curve:** Very easy

### Make (Integromat)
- **Best for:** Visual builders and complex logic
- **Pricing:** Starts at $9/month (10,000 operations)
- **Integrations:** 1,500+
- **Learning curve:** Moderate

### n8n
- **Best for:** Developers and cost-conscious teams
- **Pricing:** Free (self-hosted) or $20/month (cloud)
- **Integrations:** 400+ (growing fast)
- **Learning curve:** Moderate to advanced

## Feature Comparison

| Feature | Zapier | Make | n8n |
|---------|--------|------|-----|
| Ease of Use | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| Pricing Value | ⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Complex Logic | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Self-Hosting | ❌ | ❌ | ✅ |
| AI Features | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| Error Handling | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Webhooks | ✅ | ✅ | ✅ |
| Code Nodes | Limited | Yes | Full |

## Our Recommendation by Business Size

### Solopreneurs & Small Teams (1-5 people)
**Choose Zapier** — easiest to set up, huge integration library, simple automations.

### Growing Businesses (5-50 people)
**Choose Make** — better pricing, more powerful logic, visual workflow builder.

### Tech-Savvy Teams & Agencies
**Choose n8n** — self-host for free, complete control, AI integration capabilities.

## What We Use at Atul Automation

We use **all three** depending on the client's needs:
- **Zapier** for quick integrations
- **Make** for complex multi-step workflows  
- **n8n** for AI-heavy automations with custom code

Read our guide on [5 workflow automations](/blog/5-workflow-automations-every-small-business-needs) you should implement first, regardless of which tool you choose.

**[Need help choosing? Book a free call →](/#contact)**
        `,coverImage:"https://images.unsplash.com/photo-1558494949-ef0109159d5e?auto=format&fit=crop&q=80&w=800",category:"Tools & Reviews",author:"Atul Automation",date:"2026-02-12",readTime:"7 min read",tags:["Zapier","Make","n8n","Automation Tools","Comparison"]},{slug:"ai-automation-for-indian-small-businesses",title:"AI Automation for Indian Small Businesses: A Practical Guide",excerpt:"How Indian SMBs can use AI automation to compete with big companies. Affordable solutions that work with Indian tools — UPI, WhatsApp, Tally, and more.",content:`
## The Indian SMB Opportunity

India has **63 million MSMEs**, yet fewer than 5% use any form of automation. This means businesses that adopt AI now have a **massive first-mover advantage**.

## Why Indian SMBs Need Automation Now

### The Competition is Changing
- D2C brands are using AI for personalized marketing
- Large companies automate their entire sales pipeline
- Customers expect instant WhatsApp responses

### The Tools are Finally Affordable
- AI chatbots: ₹5,000-15,000/month
- Workflow automation: ₹2,000-10,000/month
- CRM with AI: ₹1,000-5,000/month

**Total cost of automation: Less than one employee's salary.**

## 5 Automations Perfect for Indian Business

### 1. WhatsApp Lead Bot (₹5,000/month)
Responds to every WhatsApp inquiry instantly. Qualifies leads, shares pricing, books meetings. Works in Hindi and English.

Learn more: [WhatsApp Automation Guide](/blog/whatsapp-automation-complete-guide-2026)

### 2. UPI Payment Follow-up
- Customer makes payment → Auto-receipt on WhatsApp
- EMI due → Reminder 3 days before
- Payment overdue → Gentle followup sequence

### 3. Tally Integration
- Invoice created in Tally → Auto-sent to customer
- Payment received → Tally updated automatically
- Monthly reports → Generated and shared with CA

### 4. Social Media Auto-Posting
- AI creates content in Hindi/English
- Auto-posts to Instagram, Facebook, LinkedIn
- Scheduled for optimal engagement times

### 5. Google My Business Automation
- New review → Auto-respond with thank you
- Negative review → Alert to owner immediately
- Monthly review report → Auto-generated

## Cost vs Benefit Analysis

| Investment | Monthly Cost | Monthly Benefit |
|-----------|-------------|-----------------|
| WhatsApp Bot | ₹5,000 | ₹30,000 in converted leads |
| Workflow Automation | ₹3,000 | ₹15,000 in saved labor |
| AI CRM | ₹2,000 | ₹20,000 in faster conversions |
| **Total** | **₹10,000** | **₹65,000 in value** |

**ROI: 550%** — Use our [ROI Calculator](/tools/roi-calculator) to calculate your specific numbers.

## Success Stories from Indian Businesses

**A Jaipur textile exporter** automated their entire order management:
- Order inquiries handled by AI on WhatsApp
- Quotations generated automatically
- Payment tracking integrated with Tally
- **Result:** 40% increase in order processing speed

**A Bangalore SaaS startup** automated their sales pipeline:
- AI qualifies demo requests
- Automatically schedules calls
- Follow-up sequences run on autopilot
- **Result:** 3x increase in demo-to-customer conversion

## Getting Started

We specialize in building automation for Indian businesses. Our solutions integrate with the tools you already use — WhatsApp, UPI, Tally, Razorpay, and more.

Check our [industry-specific solutions](/industries) or **[book a free strategy call →](/#contact)**.
        `,coverImage:"https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800",category:"Business Strategy",author:"Atul Automation",date:"2026-02-10",readTime:"8 min read",tags:["Indian SMB","Small Business","Affordable AI","WhatsApp","UPI"]},{slug:"automated-lead-nurturing-convert-cold-leads",title:"Automated Lead Nurturing: How to Convert Cold Leads into Paying Customers",excerpt:"Only 3% of leads are ready to buy immediately. Learn how to automatically nurture the other 97% until they convert — without hiring more salespeople.",content:`
## The Lead Nurturing Problem

Here's a truth most businesses ignore: **only 3% of your leads are ready to buy right now**. The other 97% need 5-12 touchpoints before they're ready.

Most businesses give up after 1-2 follow-ups. That's leaving **97% of potential revenue on the table**.

## What is Automated Lead Nurturing?

It's a system that automatically:
- Sends the right message at the right time
- Adapts content based on lead behavior
- Moves leads through your sales funnel
- Alerts sales when a lead becomes hot

## The Perfect Nurturing Sequence

### Week 1: Education Phase
- **Day 0:** Welcome email + quick win resource
- **Day 2:** Blog post about their pain point
- **Day 5:** Case study relevant to their industry

### Week 2-3: Trust Phase
- **Day 8:** Video testimonial from similar client
- **Day 12:** Free tool or template
- **Day 15:** Industry report or data insight

### Week 4: Decision Phase
- **Day 18:** Comparison guide (why you vs alternatives)
- **Day 22:** Limited-time offer or bonus
- **Day 25:** Personal message from founder

### Ongoing: Stay Top of Mind
- Monthly newsletter with insights
- Quarterly check-in messages
- Event and webinar invitations

## Multi-Channel Nurturing

Don't rely on email alone. Use multiple channels:

| Channel | Purpose | Frequency |
|---------|---------|-----------|
| Email | Educational content | 2-3x per week |
| WhatsApp | Quick updates, offers | 1-2x per week |
| SMS | Reminders, urgency | Sparingly |
| Retargeting Ads | Brand awareness | Continuous |
| LinkedIn | B2B relationship | Weekly |

## Measuring Success

Track these metrics:
- **Lead-to-customer conversion rate** (target: 5-15%)
- **Average nurturing duration** (how long until conversion)
- **Email open rates** (target: 25%+)
- **WhatsApp response rates** (target: 60%+)
- **Revenue attributed to nurturing**

## Tools You Need

- **Email automation:** Mailchimp, Brevo, or custom
- **WhatsApp automation:** Custom bot ([learn more](/blog/whatsapp-automation-complete-guide-2026))
- **CRM integration:** [AI-powered CRM](/blog/ai-crm-vs-manual-crm-comparison)
- **Workflow engine:** [n8n, Make, or Zapier](/blog/n8n-vs-make-vs-zapier-which-automation-tool)

## The ROI of Lead Nurturing

Companies that excel at lead nurturing generate **50% more sales-ready leads** at **33% lower cost**.

Calculate your potential savings with our **[free ROI calculator →](/tools/roi-calculator)**.

## Let Us Build It For You

At **Atul Automation**, we build complete lead nurturing systems that run on autopilot. From first touch to closed deal, every step is automated.

**[Book your free nurturing strategy session →](/#contact)**
        `,coverImage:"https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",category:"Sales Automation",author:"Atul Automation",date:"2026-02-08",readTime:"7 min read",tags:["Lead Nurturing","Sales Funnel","Email Automation","Conversion"]},{slug:"how-much-does-ai-automation-cost-2026-pricing-guide",title:"How Much Does AI Automation Cost in 2026? Complete Pricing Guide",excerpt:"Thinking about automating your business with AI? Here's exactly what it costs — from simple chatbots to full-stack enterprise automation. Real pricing, no fluff.",content:`
## The #1 Question Every Business Owner Asks

"How much will AI automation cost me?"

It's the most Googled question in the automation space — and the hardest to answer because it depends on what you're automating. But we're going to give you **real numbers** based on hundreds of projects we've delivered.

## AI Automation Pricing Tiers

### Tier 1: Basic Automation ($500 - $2,500)

**What you get:**
- Simple chatbot on your website
- Basic FAQ handling (up to 50 questions)
- Contact form automation
- Email auto-responders

**Best for:** Solopreneurs, freelancers, and micro-businesses just starting out.

**Timeline:** 1-2 weeks

### Tier 2: Growth Automation ($2,500 - $10,000)

**What you get:**
- Multi-channel chatbot (website + WhatsApp + Instagram)
- CRM integration (HubSpot, Salesforce, or Zoho)
- Automated lead scoring and routing
- Email nurture sequences (5-10 touchpoints)
- Basic analytics dashboard

**Best for:** Small businesses with 10-50 employees processing 100+ leads/month.

**Timeline:** 3-6 weeks

### Tier 3: Enterprise Automation ($10,000 - $50,000+)

**What you get:**
- Custom AI agents powered by GPT-4 or Claude
- Full workflow automation across your tech stack
- Custom integrations via APIs and webhooks
- Predictive analytics and reporting
- Dedicated support and optimization
- Multi-language support

**Best for:** Companies with 50+ employees, complex workflows, and high-volume operations.

**Timeline:** 6-12 weeks

## Cost Comparison: AI vs Manual Operations

| Task | Manual Cost/Month | AI Cost/Month | Savings |
|------|-------------------|---------------|---------|
| Customer Support (24/7) | $8,000 - $15,000 | $500 - $2,000 | 85-93% |
| Lead Qualification | $4,000 - $6,000 | $300 - $800 | 87-92% |
| Data Entry & Processing | $3,000 - $5,000 | $200 - $500 | 90-93% |
| Email Marketing | $2,000 - $4,000 | $100 - $400 | 90-95% |
| Social Media Management | $3,000 - $6,000 | $500 - $1,500 | 75-83% |

## Hidden Costs to Watch For

### 1. API Usage Fees
GPT-4 and Claude charge per token. For most businesses, this runs **$50-200/month**. High-volume operations may see $500+/month.

### 2. Tool Subscriptions
Zapier, Make, or n8n subscriptions typically cost **$20-100/month** depending on usage.

### 3. Maintenance & Updates
AI models improve rapidly. Budget **10-15% of initial build cost** annually for updates.

## ROI Calculator

Most businesses see ROI within **30-60 days**. Calculate yours with our [free ROI Calculator](/tools/roi-calculator).

## The Bottom Line

For small businesses, you can start automating for **under $1,000**. For serious growth, budget **$5,000-15,000** for a system that pays for itself within 2 months.

**[Get a free custom quote →](/#contact)** — we'll analyze your specific workflows and give you exact pricing.
        `,coverImage:"https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&q=80&w=800",category:"Business Strategy",author:"Atul Automation",date:"2026-03-05",readTime:"8 min read",tags:["AI Pricing","Automation Cost","Business ROI","AI Budget","Small Business"]},{slug:"ai-automation-vs-hiring-employees-cost-comparison",title:"AI Automation vs Hiring Employees: The Real Cost Comparison for 2026",excerpt:"Should you hire another employee or invest in AI automation? We break down the real costs, productivity gains, and long-term ROI of both options.",content:`
## The Hiring Dilemma

Your business is growing. You need more capacity. The traditional answer is to hire. But in 2026, there's a smarter option: **AI automation**.

Let's compare the real costs side-by-side.

## The True Cost of Hiring an Employee

Most business owners only think about salary. But the **actual cost of an employee** is 1.3-1.5x their salary:

| Cost Category | Annual Amount |
|---------------|--------------|
| Base Salary | $45,000 - $75,000 |
| Health Insurance | $7,000 - $15,000 |
| Payroll Taxes | $3,500 - $6,000 |
| Office Space & Equipment | $5,000 - $12,000 |
| Training & Onboarding | $2,000 - $5,000 |
| PTO & Sick Days | $3,000 - $6,000 |
| **Total Annual Cost** | **$65,500 - $119,000** |

And that's just one employee. They work **8 hours/day, 5 days/week**, need vacation, get sick, and eventually leave (average tenure: 2.5 years).

## The Cost of AI Automation

| Cost Category | Annual Amount |
|---------------|--------------|
| Initial Setup (one-time) | $2,000 - $15,000 |
| Monthly Platform Fees | $1,200 - $6,000/yr |
| API Usage (GPT-4/Claude) | $600 - $2,400/yr |
| Maintenance & Updates | $1,200 - $3,600/yr |
| **Total Year 1 Cost** | **$5,000 - $27,000** |
| **Total Year 2+ Cost** | **$3,000 - $12,000** |

AI works **24/7/365**. No breaks, no sick days, no turnover. And it gets **better** over time, not burned out.

## Head-to-Head Comparison

| Factor | Human Employee | AI Automation |
|--------|---------------|---------------|
| Availability | 8 hrs/day, 5 days/week | 24/7/365 |
| Response Time | 2-5 minutes | Under 3 seconds |
| Scalability | Hire more people | Flip a switch |
| Consistency | Variable (mood, energy) | 100% consistent |
| Annual Cost | $65,000 - $119,000 | $5,000 - $27,000 |
| Ramp-up Time | 2-6 months | 1-4 weeks |
| Turnover Risk | High (35% annual avg) | Zero |
| Language Support | 1-2 languages | 50+ languages |

## When to Hire vs When to Automate

### Automate When:
- Tasks are repetitive and rule-based
- You need 24/7 availability
- Volume fluctuates (peaks and valleys)
- Speed matters (instant responses)
- The task involves data processing

### Hire When:
- Tasks require deep human empathy
- Creative strategy and innovation needed
- Complex negotiations required
- Physical presence is necessary
- Building long-term client relationships

## The Hybrid Approach (Our Recommendation)

The smartest companies **do both**. They automate the repetitive 80% and hire humans for the strategic 20%.

**Example:** A real estate firm uses AI to handle lead inquiry responses (automated) but has human agents for property showings and negotiations (personal touch).

## Real Client Case Study

A San Francisco SaaS startup was about to hire 3 customer support reps at $55,000 each (total: $165,000/year). Instead, they invested $12,000 in AI automation:

- **Result:** AI handles 85% of support tickets automatically
- **Cost savings:** $153,000/year
- **They hired 1 human** for complex escalations instead of 3
- **Customer satisfaction:** Actually improved from 78% to 92%

**[Calculate your savings →](/tools/roi-calculator)** or **[talk to our team →](/#contact)**
        `,coverImage:"https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=800",category:"Business Strategy",author:"Atul Automation",date:"2026-03-04",readTime:"9 min read",tags:["AI vs Hiring","Cost Comparison","Business Growth","HR Automation","Staffing"]},{slug:"best-ai-tools-for-small-business-2026",title:"15 Best AI Tools for Small Business in 2026 (Free & Paid)",excerpt:"The ultimate guide to AI tools every small business should be using. From chatbots to marketing automation — ranked by value, ease of use, and pricing.",content:`
## Why Small Businesses Need AI Tools Now

In 2026, AI isn't just for tech giants. **73% of small businesses** that adopted AI tools reported significant time savings and revenue growth. Here are the 15 best tools you should know about.

## Communication & Customer Support

### 1. ChatGPT for Business (OpenAI)
- **What it does:** AI-powered content writing, email drafting, brainstorming
- **Pricing:** Free tier available, Plus at $20/month
- **Best for:** Content creation, customer email templates
- **Our take:** Essential for any business. Start here.

### 2. Intercom + Fin AI
- **What it does:** AI customer support chatbot that learns from your docs
- **Pricing:** From $74/month
- **Best for:** SaaS companies and e-commerce
- **Our take:** Great out-of-the-box, but expensive at scale. [We build custom alternatives](/capabilities/chatbots) for 40% less.

### 3. Tidio
- **What it does:** Live chat + AI chatbot for websites
- **Pricing:** Free tier, paid from $29/month
- **Best for:** E-commerce stores and service businesses

## Marketing & Sales

### 4. Jasper AI
- **What it does:** AI copywriting for ads, blogs, social media
- **Pricing:** From $49/month
- **Best for:** Marketing teams short on content writers

### 5. Apollo.io
- **What it does:** AI-powered sales prospecting and outreach
- **Pricing:** Free tier, paid from $49/month
- **Best for:** B2B companies doing outbound sales

### 6. Surfer SEO
- **What it does:** AI content optimization for search rankings
- **Pricing:** From $89/month
- **Best for:** Businesses serious about organic traffic

## Workflow Automation

### 7. Zapier
- **What it does:** Connects 6,000+ apps with no-code automation
- **Pricing:** Free tier (100 tasks/month), paid from $19.99/month
- **Best for:** Simple app-to-app automations
- Read our [detailed comparison](/blog/n8n-vs-make-vs-zapier-which-automation-tool)

### 8. Make (formerly Integromat)
- **What it does:** Visual workflow automation with complex logic
- **Pricing:** Free tier (1,000 ops/month), paid from $9/month
- **Best for:** Complex multi-step workflows

### 9. n8n
- **What it does:** Self-hosted workflow automation with AI nodes
- **Pricing:** Free (self-hosted), cloud from $20/month
- **Best for:** Tech-savvy teams wanting full control

## Design & Creative

### 10. Canva AI (Magic Studio)
- **What it does:** AI-generated designs, presentations, videos
- **Pricing:** Free tier, Pro from $12.99/month
- **Best for:** Social media graphics and marketing materials

### 11. Midjourney / DALL-E 3
- **What it does:** AI image generation from text prompts
- **Pricing:** Midjourney from $10/month, DALL-E 3 via ChatGPT Plus ($20/month)
- **Best for:** Product mockups, social media visuals, branding

## Data & Analytics

### 12. Notion AI
- **What it does:** AI-powered docs, project management, knowledge bases
- **Pricing:** Free tier, AI add-on $8/member/month
- **Best for:** Team collaboration and documentation

### 13. Fireflies.ai
- **What it does:** AI meeting transcription and action items
- **Pricing:** Free tier, Pro from $10/month
- **Best for:** Sales teams and consulting firms

## CRM & Customer Management

### 14. HubSpot AI
- **What it does:** AI-powered CRM with predictive lead scoring
- **Pricing:** Free CRM, paid from $45/month
- **Best for:** Growing businesses with sales teams
- Learn more about [AI-powered CRMs](/blog/ai-crm-vs-manual-crm-comparison)

### 15. Freshdesk AI (Freddy)
- **What it does:** AI ticketing and customer support management
- **Pricing:** Free tier, paid from $15/agent/month
- **Best for:** Support-heavy businesses

## Our Top 5 Picks (If You Had to Choose)

| Rank | Tool | Why |
|------|------|-----|
| 1 | ChatGPT Plus | Most versatile, cheap, essential |
| 2 | Zapier | Automate anything, huge integrations |
| 3 | HubSpot CRM | Free tier is incredibly powerful |
| 4 | Canva AI | Design without a designer |
| 5 | Surfer SEO | Organic traffic = free leads |

## Need a Custom Stack?

Every business is different. At **Atul Automation**, we audit your current tools and build a custom automation stack that saves you 20+ hours per week.

**[Get your free tool audit →](/#contact)** — we'll recommend the perfect AI stack for your business.
        `,coverImage:"https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=800",category:"Tools & Reviews",author:"Atul Automation",date:"2026-03-03",readTime:"12 min read",tags:["AI Tools","Small Business","SaaS","Productivity","Best Tools 2026"]},{slug:"ai-customer-service-chatbot-complete-roi-guide",title:"AI Customer Service Chatbots: The Complete ROI Guide for Business",excerpt:"AI chatbots can cut your support costs by 60% while improving satisfaction scores. Here's exactly how to measure and maximize your chatbot ROI.",content:`
## Why AI Customer Service is No Longer Optional

**67% of US consumers** have interacted with an AI chatbot for customer service in the past year. And **40% don't care** whether they're talking to a human or AI — as long as their problem gets solved quickly.

If your competitors have AI support and you don't, you're losing customers every single day.

## The ROI Framework for AI Chatbots

### Direct Cost Savings

The average US customer service agent costs **$35,000-$45,000/year** (salary + benefits + overhead). An AI chatbot handling the same volume costs **$200-$500/month**.

| Metric | Human Support | AI Chatbot |
|--------|--------------|------------|
| Cost per interaction | $5.50 - $12.00 | $0.10 - $0.25 |
| Average response time | 4+ hours | Under 5 seconds |
| Availability | Business hours | 24/7/365 |
| Concurrent conversations | 3-5 max | Unlimited |
| Language support | 1-2 | 95+ |
| Consistency | Variable | 100% |

### Revenue Gains from AI Chatbots

AI chatbots don't just save money — they **generate revenue**:

**1. Faster Lead Response = More Conversions**
Studies show responding to a lead within 5 minutes makes you **21x more likely** to qualify them. AI responds in 3 seconds.

**2. 24/7 Sales Coverage**
35% of online purchases happen after business hours. Without AI, you're missing a third of potential sales.

**3. Upselling & Cross-selling**
Smart chatbots recommend products based on browsing behavior, increasing average order value by **10-30%**.

**4. Reduced Cart Abandonment**
AI chatbots that engage during checkout can recover **15-25% of abandoned carts** — worth thousands per month for e-commerce.

## Real-World ROI Numbers

### Case Study: Mid-Size E-Commerce Brand

**Before AI:** 3 support agents handling 150 tickets/day. Monthly cost: $12,500.

**After AI:** Chatbot handles 80% of tickets. 1 agent handles escalations. Monthly cost: $5,200.

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Monthly support cost | $12,500 | $5,200 | -58% |
| Avg response time | 3.5 hours | 8 seconds | -99.9% |
| CSAT score | 72% | 89% | +17 pts |
| Tickets resolved/day | 150 | 400 | +167% |
| Revenue from chat | $0 | $8,400/mo | New revenue |
| **Net monthly impact** | | | **+$15,700** |

### Case Study: Professional Services Firm

A New York consulting firm deployed AI chatbot for lead qualification:

- **Inbound leads qualified automatically:** 340/month (up from 85 manual)
- **Sales team time saved:** 25 hours/week
- **New revenue attributed to AI:** $47,000/quarter
- **Investment:** $8,000 setup + $400/month

**ROI:** 1,175% in first year.

## How to Maximize Your Chatbot ROI

### 1. Train on YOUR Data
Generic chatbots give generic answers. Feed your chatbot your actual FAQ docs, product catalogs, and past support conversations.

### 2. Set Up Smart Escalation
Don't let the chatbot try to handle everything. Program clear escalation triggers for complex issues — frustrated customers, billing disputes, technical bugs.

### 3. Measure Everything
Track: resolution rate, CSAT after chat, escalation rate, conversion rate, and revenue influenced.

### 4. Continuously Improve
Review chatbot conversations weekly. Identify failure patterns and add new training data. The best chatbots improve monthly.

## Getting Started

At **Atul Automation**, we build custom AI chatbots that integrate with your existing tools. Our chatbots are powered by GPT-4 and Claude — not generic template bots.

**Average client ROI:** 400-800% in the first year.

**[See how much you could save →](/tools/roi-calculator)** or **[book a demo →](/#contact)**
        `,coverImage:"https://images.unsplash.com/photo-1543286386-713bdd54865e?auto=format&fit=crop&q=80&w=800",category:"AI Chatbots",author:"Atul Automation",date:"2026-03-02",readTime:"10 min read",tags:["AI Chatbot","Customer Service","ROI","Support Automation","Cost Savings"]},{slug:"what-are-ai-agents-how-they-automate-business",title:"What Are AI Agents? How Autonomous AI is Transforming Business in 2026",excerpt:"AI agents go beyond chatbots — they can think, plan, and execute multi-step tasks autonomously. Learn how businesses are using them to 10x productivity.",content:`
## Beyond Chatbots: The Rise of AI Agents

You've heard of AI chatbots. But **AI agents** are something entirely different — and far more powerful.

While a chatbot answers questions, an AI agent can **plan, reason, and execute complex multi-step tasks** on its own. Think of it as giving AI a job description and letting it work autonomously.

## What Exactly is an AI Agent?

An AI agent is a software program that can:

- **Perceive** its environment (read emails, monitor data, scan websites)
- **Reason** about what to do (analyze context, make decisions)
- **Act** independently (send emails, update databases, create reports)
- **Learn** from outcomes (improve over time)

### Chatbot vs AI Agent

| Capability | Chatbot | AI Agent |
|-----------|---------|----------|
| Answer questions | ✅ | ✅ |
| Multi-step tasks | ❌ | ✅ |
| Use external tools | ❌ | ✅ |
| Make decisions | ❌ | ✅ |
| Work autonomously | ❌ | ✅ |
| Learn from outcomes | Limited | ✅ |
| Execute workflows | ❌ | ✅ |

## 7 Ways Businesses Use AI Agents in 2026

### 1. Sales Development Representative (SDR) Agent

**What it does:** Researches prospects, writes personalized outreach emails, follows up, and books meetings — all automatically.

**Impact:** One AI SDR agent can do the work of 3-5 human SDRs, sending 500+ personalized emails per day with 15-25% response rates.

**Cost:** $300-800/month vs $55,000/year for a human SDR.

### 2. Customer Support Agent

**What it does:** Handles incoming support tickets across email, chat, and social media. Resolves common issues independently, escalates complex ones with full context.

**Impact:** Resolves 70-85% of tickets without human intervention. Average response time: 8 seconds vs 4+ hours.

### 3. Content Marketing Agent

**What it does:** Researches trending topics, writes SEO-optimized blog posts, creates social media variants, and schedules publishing.

**Impact:** Produces 10-20 pieces of content per week vs 2-3 from a human writer.

### 4. Data Analysis Agent

**What it does:** Pulls data from multiple sources (Google Analytics, CRM, ad platforms), identifies trends, generates insights, and creates reports.

**Impact:** Replaces 5-10 hours of weekly report building with real-time automated dashboards.

### 5. Recruitment Agent

**What it does:** Screens resumes, identifies top candidates, sends personalized outreach, and schedules interviews.

**Impact:** Reduces time-to-hire by 60% and screens 10x more candidates.

### 6. Financial Operations Agent

**What it does:** Processes invoices, reconciles accounts, flags anomalies, and generates financial reports.

**Impact:** Reduces accounting errors by 95% and saves 15+ hours/week.

### 7. IT Support Agent

**What it does:** Handles password resets, software provisioning, troubleshooting common issues, and escalating complex tickets.

**Impact:** Resolves 70% of IT tickets instantly, saving $50,000+/year for mid-size companies.

## The Technology Behind AI Agents

### Large Language Models (LLMs)
The "brain" of the agent. GPT-4, Claude, and Gemini provide reasoning and language understanding capabilities.

### Tool Use / Function Calling
Agents can use external tools — search the web, query databases, send emails, update spreadsheets, call APIs.

### Memory Systems
Short-term memory (conversation context) and long-term memory (learning from past interactions) help agents improve over time.

### Orchestration Frameworks
Tools like LangChain, CrewAI, and AutoGen help developers build multi-agent systems where specialized agents collaborate.

## Getting Started with AI Agents

### Start Small
Don't try to automate everything at once. Pick **one high-impact, repetitive task** and build an agent for that.

### Measure ROI
Track time saved, cost reduced, and revenue generated. Most businesses see ROI within 30-60 days.

### Scale Gradually
Once your first agent proves value, expand to adjacent processes. Build a network of specialized agents.

## Why Work with Atul Automation?

We specialize in building **custom AI agents** tailored to your business. Not generic templates — purpose-built autonomous systems that integrate with your existing tools.

Our agents are powered by the latest models (GPT-4, Claude 3.5) and built with enterprise-grade security and reliability.

**[Explore our AI Agent capabilities →](/capabilities/ai-agents)** or **[schedule a strategy call →](/#contact)**
        `,coverImage:"https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=800",category:"AI Technology",author:"Atul Automation",date:"2026-03-01",readTime:"11 min read",tags:["AI Agents","Autonomous AI","GPT-4","Claude","Business Automation","LLM"]}],b={"AI Chatbots":{icon:n.Bot,gradient:"from-blue-600 via-cyan-500 to-teal-400"},"Workflow Automation":{icon:l.Zap,gradient:"from-amber-500 via-orange-500 to-red-500"},"AI Marketing":{icon:p.Megaphone,gradient:"from-pink-500 via-rose-500 to-red-500"},WhatsApp:{icon:n.Bot,gradient:"from-green-500 via-emerald-500 to-teal-500"},CRM:{icon:c.Users,gradient:"from-indigo-500 via-purple-500 to-pink-500"},"Tools & Reviews":{icon:u,gradient:"from-violet-500 via-fuchsia-500 to-pink-500"},"Business Strategy":{icon:d.DollarSign,gradient:"from-emerald-500 via-green-500 to-lime-500"},"Sales Automation":{icon:h.BarChart3,gradient:"from-sky-500 via-blue-500 to-indigo-500"},"AI Technology":{icon:m.Brain,gradient:"from-purple-600 via-violet-500 to-indigo-500"}},f={icon:l.Zap,gradient:"from-primary via-orange-500 to-amber-500"};function y(){let e=x.sort((e,t)=>new Date(t.date).getTime()-new Date(e.date).getTime()).slice(0,3);return(0,t.jsxs)("section",{id:"blog",className:"section-padding bg-transparent relative",children:[(0,t.jsx)("div",{className:"absolute top-0 left-1/2 -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent rounded-full"}),(0,t.jsxs)("div",{className:"container-custom",children:[(0,t.jsxs)("div",{className:"max-w-2xl mx-auto text-center mb-16 opacity-0 animate-fade-in-up",children:[(0,t.jsxs)("p",{className:"section-badge mb-4",children:[(0,t.jsx)(s.BookOpen,{className:"h-3.5 w-3.5"})," Blog"]}),(0,t.jsxs)("h2",{className:"text-3xl md:text-5xl font-bold mb-4",children:["Latest ",(0,t.jsx)("span",{className:"text-primary",children:"Insights"})]}),(0,t.jsx)("p",{className:"text-muted-foreground text-lg",children:"Stay ahead with expert takes on AI, automation, and digital growth."})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:e.map((e,s)=>{let r=(b[e.category]||f).icon;return(0,t.jsx)(g.default,{href:`/blog/${e.slug}`,className:"group block",children:(0,t.jsxs)("article",{className:"h-full bg-card border border-border rounded-2xl overflow-hidden hover:shadow-xl hover:border-primary/20 transition-all duration-300 cursor-pointer relative opacity-0 animate-fade-in-up",style:{animationDelay:`${(s+1)*100}ms`},children:[(0,t.jsxs)("div",{className:"relative h-44 overflow-hidden bg-muted",children:[(0,t.jsx)("img",{src:e.coverImage,alt:e.title,className:"w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"}),(0,t.jsx)("div",{className:"absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"}),(0,t.jsx)("div",{className:"absolute top-3 left-3",children:(0,t.jsx)("span",{className:"inline-flex items-center rounded-full bg-primary/90 backdrop-blur-sm px-2.5 py-1 text-[10px] font-bold text-white shadow-lg",children:e.category})}),(0,t.jsx)("div",{className:"absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none",children:(0,t.jsx)("div",{className:"w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white scale-75 group-hover:scale-100 transition-transform duration-500 ring-1 ring-white/30",children:(0,t.jsx)(r,{className:"h-5 w-5",strokeWidth:2})})})]}),(0,t.jsxs)("div",{className:"p-5",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3 mb-3",children:[(0,t.jsxs)("span",{className:"text-[11px] text-muted-foreground flex items-center gap-1",children:[(0,t.jsx)(i,{className:"h-3 w-3"}),new Date(e.date).toLocaleDateString("en-US",{day:"numeric",month:"short",year:"numeric"})]}),(0,t.jsx)("span",{className:"text-muted-foreground/30",children:"·"}),(0,t.jsxs)("span",{className:"text-[11px] text-muted-foreground flex items-center gap-1",children:[(0,t.jsx)(o.Clock,{className:"h-3 w-3"})," ",e.readTime]})]}),(0,t.jsx)("h3",{className:"text-lg font-bold mb-2 group-hover:text-primary transition-colors leading-snug line-clamp-2",children:e.title}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-2",children:e.excerpt}),(0,t.jsxs)("div",{className:"flex items-center justify-between pt-4 border-t border-border/50",children:[(0,t.jsx)("span",{className:"text-xs text-muted-foreground",children:e.author}),(0,t.jsxs)("span",{className:"text-sm font-semibold text-primary flex items-center gap-1 group-hover:gap-2 transition-all",children:["Read ",(0,t.jsx)(a.ArrowRight,{className:"h-3.5 w-3.5"})]})]})]})]})},e.slug)})}),(0,t.jsx)("div",{className:"text-center mt-10",children:(0,t.jsxs)(g.default,{href:"/blog",className:"inline-flex items-center gap-2 text-sm font-semibold text-primary hover:gap-3 transition-all",children:["View All Articles ",(0,t.jsx)(a.ArrowRight,{className:"h-4 w-4"})]})})]})]})}e.s(["Blog",()=>y],52866)}]);