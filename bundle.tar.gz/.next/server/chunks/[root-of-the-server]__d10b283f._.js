module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},75922,e=>{"use strict";var t=e.i(47909),r=e.i(74017),a=e.i(96250),s=e.i(59756),i=e.i(61916),n=e.i(74677),o=e.i(69741),d=e.i(16795),l=e.i(87718),c=e.i(95169),u=e.i(47587),p=e.i(66012),m=e.i(70101),x=e.i(26937),h=e.i(10372),g=e.i(93695);e.i(52474);var v=e.i(220),f=e.i(89171),b=e.i(29642);async function y(e){try{let{prompt:t}=await e.json();if(!t)return f.NextResponse.json({error:"Prompt is required"},{status:400});let r=process.env.GEMINI_API_KEY;if(!r){console.warn("GEMINI_API_KEY is not set in .env.local. Returning a mocked prototype."),await new Promise(e=>setTimeout(e,3e3));let e=`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generated Prototype</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              primary: '#F97316',
            }
          }
        }
      }
    </script>
</head>
<body class="bg-gray-50 text-gray-900 font-sans min-h-screen flex">
    <!-- Sidebar -->
    <aside class="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div class="h-16 flex items-center px-6 border-b border-gray-200">
            <i data-lucide="sparkles" class="text-primary w-5 h-5 mr-2"></i>
            <span class="font-bold text-lg tracking-tight">App Builder Demo</span>
        </div>
        <nav class="flex-1 p-4 space-y-1">
            <a href="#" class="flex items-center px-3 py-2 text-primary bg-orange-50 rounded-md font-medium text-sm">
                <i data-lucide="layout-dashboard" class="w-4 h-4 mr-3"></i> Dashboard
            </a>
            <a href="#" class="flex items-center px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-md font-medium text-sm transition-colors">
                <i data-lucide="users" class="w-4 h-4 mr-3"></i> Users
            </a>
            <a href="#" class="flex items-center px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-md font-medium text-sm transition-colors">
                <i data-lucide="bar-chart-3" class="w-4 h-4 mr-3"></i> Analytics
            </a>
            <a href="#" class="flex items-center px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-md font-medium text-sm transition-colors">
                <i data-lucide="settings" class="w-4 h-4 mr-3"></i> Settings
            </a>
        </nav>
        <div class="p-4 border-t border-gray-200">
            <div class="bg-blue-50 text-blue-700 p-3 rounded-md text-xs font-semibold">
                ⚠️ GEMINI_API_KEY not found. Showing mock data. Please add your key to .env.local for dynamic generation!
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 flex flex-col">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8">
            <h1 class="text-xl font-semibold opacity-80">Overview: \${prompt}</h1>
            <div class="flex items-center gap-4">
                <button class="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center hover:bg-gray-50">
                    <i data-lucide="bell" class="w-4 h-4 text-gray-500"></i>
                </button>
                <div class="w-8 h-8 rounded-full bg-primary/20 border border-primary text-primary flex items-center justify-center font-bold text-xs">
                    AA
                </div>
            </div>
        </header>

        <div class="p-8 flex-1 overflow-y-auto">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <!-- Stat Cards -->
                <div class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                    <div class="text-gray-500 text-sm font-medium mb-1 flex items-center justify-between">
                        Total Revenue <i data-lucide="dollar-sign" class="w-4 h-4 text-gray-400"></i>
                    </div>
                    <div class="text-3xl font-bold tracking-tight">$45,231.89</div>
                    <div class="text-green-500 text-xs font-semibold mt-2 flex items-center">
                        <i data-lucide="trending-up" class="w-3 h-3 mr-1"></i> +20.1% from last month
                    </div>
                </div>
                <div class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                    <div class="text-gray-500 text-sm font-medium mb-1 flex items-center justify-between">
                        Active Users <i data-lucide="users" class="w-4 h-4 text-gray-400"></i>
                    </div>
                    <div class="text-3xl font-bold tracking-tight">+2,350</div>
                    <div class="text-green-500 text-xs font-semibold mt-2 flex items-center">
                        <i data-lucide="trending-up" class="w-3 h-3 mr-1"></i> +15.5% from last month
                    </div>
                </div>
                <div class="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                    <div class="text-gray-500 text-sm font-medium mb-1 flex items-center justify-between">
                        Active Sessions <i data-lucide="activity" class="w-4 h-4 text-gray-400"></i>
                    </div>
                    <div class="text-3xl font-bold tracking-tight">+12,234</div>
                    <div class="text-red-500 text-xs font-semibold mt-2 flex items-center">
                        <i data-lucide="trending-down" class="w-3 h-3 mr-1"></i> -4.2% from last month
                    </div>
                </div>
            </div>

            <!-- Content Area -->
            <div class="bg-white rounded-xl border border-gray-100 shadow-sm flex flex-col overflow-hidden h-96">
                <div class="p-4 border-b border-gray-100 font-semibold text-gray-700 flex justify-between items-center">
                    Recent Activity
                    <button class="text-xs text-primary font-medium hover:underline">View All</button>
                </div>
                <!-- Mock Chart Area -->
                <div class="flex-1 flex items-center justify-center bg-gray-50/50">
                    <div class="text-center">
                        <i data-lucide="bar-chart-2" class="w-16 h-16 text-gray-300 mx-auto mb-4"></i>
                        <p class="text-gray-400 text-sm font-medium">Interactive Graph Area</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
      lucide.createIcons();
    </script>
</body>
</html>
      `.replace(/\${prompt}/g,t);return f.NextResponse.json({html:e})}let a=new b.GoogleGenerativeAI(r).getGenerativeModel({model:"gemini-2.5-flash"}),s=`
You are an expert UI/UX developer and frontend engineer. 
Your task is to generate a fully functional, beautiful, modern, single-file HTML prototype based on the user's prompt.
You MUST use Tailwind CSS via CDN (<script src="https://cdn.tailwindcss.com"></script>).
You MUST use Lucide icons via CDN (<script src="https://unpkg.com/lucide@latest"></script>) and initialize them with lucide.createIcons(); at the end of the body.
Ensure the design looks extremely premium, using modern layout paradigms (Grid/Flexbox), soft shadows, nice borders, and rounded corners.

CRITICAL RULES:
1. Return ONLY the raw HTML code. 
2. NO markdown formatting blocks like "\`\`\`html" or "\`\`\`". Just output the raw <html> string starting from <!DOCTYPE html>.
3. Include inline JavaScript for basic interactivity if it makes sense (like a togglable sidebar or tabs), but it is optional.
`,i=(await a.generateContent([s,`User requested UI: "${t}"`])).response.text().replace(/^\`\`\`(html)?/,"").replace(/\`\`\`$/,"").trim();return f.NextResponse.json({html:i})}catch(e){return console.error("UI Generation Error:",e),f.NextResponse.json({error:"Failed to generate prototype.",details:e.message},{status:500})}}e.s(["POST",()=>y],18111);var w=e.i(18111);let R=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/generate-ui/route",pathname:"/api/generate-ui",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/generate-ui/route.ts",nextConfigOutput:"",userland:w}),{workAsyncStorage:E,workUnitAsyncStorage:C,serverHooks:A}=R;function k(){return(0,a.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:C})}async function T(e,t,a){R.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let f="/api/generate-ui/route";f=f.replace(/\/index$/,"")||"/";let b=await R.prepare(e,t,{srcPage:f,multiZoneDraftMode:!1});if(!b)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:y,params:w,nextConfig:E,parsedUrl:C,isDraftMode:A,prerenderManifest:k,routerServerContext:T,isOnDemandRevalidate:I,revalidateOnlyGenerated:N,resolvedPathname:P,clientReferenceManifest:S,serverActionsManifest:j}=b,O=(0,o.normalizeAppPath)(f),U=!!(k.dynamicRoutes[O]||k.routes[P]),_=async()=>((null==T?void 0:T.render404)?await T.render404(e,t,C,!1):t.end("This page could not be found"),null);if(U&&!A){let e=!!k.routes[P],t=k.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(E.experimental.adapterPath)return await _();throw new g.NoFallbackError}}let q=null;!U||R.isDev||A||(q="/index"===(q=P)?"/":q);let M=!0===R.isDev||!U,D=U&&!M;j&&S&&(0,n.setManifestsSingleton)({page:f,clientReferenceManifest:S,serverActionsManifest:j});let H=e.method||"GET",$=(0,i.getTracer)(),G=$.getActiveScopeSpan(),F={params:w,prerenderManifest:k,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:M,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:E.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,s)=>R.onRequestError(e,t,a,s,T)},sharedContext:{buildId:y}},K=new d.NodeNextRequest(e),L=new d.NodeNextResponse(t),Y=l.NextRequestAdapter.fromNodeNextRequest(K,(0,l.signalFromNodeResponse)(t));try{let n=async e=>R.handle(Y,F).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=$.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${H} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${H} ${f}`)}),o=!!(0,s.getRequestMeta)(e,"minimalMode"),d=async s=>{var i,d;let l=async({previousCacheEntry:r})=>{try{if(!o&&I&&N&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let i=await n(s);e.fetchMetrics=F.renderOpts.fetchMetrics;let d=F.renderOpts.pendingWaitUntil;d&&a.waitUntil&&(a.waitUntil(d),d=void 0);let l=F.renderOpts.collectedTags;if(!U)return await (0,p.sendResponse)(K,L,i,F.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),t=(0,m.toNodeOutgoingHttpHeaders)(i.headers);l&&(t[h.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=h.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,a=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=h.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await R.onRequestError(e,t,{routerKind:"App Router",routePath:f,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:I})},!1,T),t}},c=await R.handleResponse({req:e,nextConfig:E,cacheKey:q,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:k,isRoutePPREnabled:!1,isOnDemandRevalidate:I,revalidateOnlyGenerated:N,responseGenerator:l,waitUntil:a.waitUntil,isMinimalMode:o});if(!U)return null;if((null==c||null==(i=c.value)?void 0:i.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==c||null==(d=c.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",I?"REVALIDATED":c.isMiss?"MISS":c.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let g=(0,m.fromNodeOutgoingHttpHeaders)(c.value.headers);return o&&U||g.delete(h.NEXT_CACHE_TAGS_HEADER),!c.cacheControl||t.getHeader("Cache-Control")||g.get("Cache-Control")||g.set("Cache-Control",(0,x.getCacheControlHeader)(c.cacheControl)),await (0,p.sendResponse)(K,L,new Response(c.value.body,{headers:g,status:c.value.status||200})),null};G?await d(G):await $.withPropagatedContext(e.headers,()=>$.trace(c.BaseServerSpan.handleRequest,{spanName:`${H} ${f}`,kind:i.SpanKind.SERVER,attributes:{"http.method":H,"http.target":e.url}},d))}catch(t){if(t instanceof g.NoFallbackError||await R.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:I})},!1,T),U)throw t;return await (0,p.sendResponse)(K,L,new Response(null,{status:500})),null}}e.s(["handler",()=>T,"patchFetch",()=>k,"routeModule",()=>R,"serverHooks",()=>A,"workAsyncStorage",()=>E,"workUnitAsyncStorage",()=>C],75922)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__d10b283f._.js.map