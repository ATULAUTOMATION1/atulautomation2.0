module.exports=[48875,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_ai-readiness-quiz_page_actions_1686d035.js.map