module.exports=[13672,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_generate-ui_route_actions_14458ed5.js.map