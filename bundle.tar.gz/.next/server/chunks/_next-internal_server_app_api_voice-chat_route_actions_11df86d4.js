module.exports=[67400,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_voice-chat_route_actions_11df86d4.js.map