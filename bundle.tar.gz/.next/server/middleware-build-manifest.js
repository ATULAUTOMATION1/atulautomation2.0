globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/513c0a30a810a172.js",
    "static/chunks/f091501564eb2ea3.js",
    "static/chunks/05033f5d81f686f0.js",
    "static/chunks/d66b8353d27d52cd.js",
    "static/chunks/turbopack-4a9b3ab04dae46e9.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];