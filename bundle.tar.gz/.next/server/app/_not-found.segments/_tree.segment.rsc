:HL["/_next/static/chunks/b994f0527d7d13b2.css","style"]
:HL["/_next/static/chunks/27b459476113165d.css","style"]
:HL["/_next/static/chunks/13e534a493097253.css","style"]
0:{"buildId":"G1SsOqE_g1OkQDsb3x1Gx","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
