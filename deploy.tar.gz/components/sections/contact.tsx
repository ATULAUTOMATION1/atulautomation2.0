"use client";

import { useState } from "react";
import { Send, Mail, Phone, MapPin, ArrowRight, CheckCircle, Sparkles, Shield, Clock, Award } from "lucide-react";

export function Contact() {
    const [submitted, setSubmitted] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        service: "Select a Service",
        message: ""
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });

            const data = await response.json();

            if (response.ok && data.success) {
                setSubmitted(true);
            } else {
                alert(data.message || "Failed to send message. Please try again.");
            }
        } catch (error) {
            console.error("Error submitting form:", error);
            alert("Something went wrong. Please try again later.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
        <section id="contact" className="section-padding bg-transparent relative">
            {/* Section accent */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent rounded-full" />

            <div className="container-custom">
                {/* CTA Banner */}
                <div className="relative bg-gradient-to-br from-primary via-orange-500 to-primary rounded-3xl p-10 md:p-14 text-center text-white mb-16 overflow-hidden opacity-0 animate-fade-in-up">
                    {/* Animated shine */}
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12 animate-shimmer pointer-events-none" />
                    {/* Decorative circles */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/3" />
                    <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/3" />

                    <div className="relative z-10">
                        <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm px-4 py-2 rounded-full mb-6 animate-pulse">
                            <Sparkles className="h-3.5 w-3.5" />
                            <span className="text-xs font-bold tracking-wider uppercase">Limited Time Offer</span>
                        </div>
                        <h2 className="text-3xl md:text-5xl font-bold mb-4">Ready to 10x Your Business?</h2>
                        <p className="text-white/80 text-lg mb-8 max-w-lg mx-auto">Get a free automation strategy call. No commitment, just clarity.</p>
                        <a href="#contact-form" className="inline-flex items-center gap-2 bg-white text-primary font-bold px-8 py-3.5 rounded-full hover:bg-white/90 hover:shadow-2xl hover:shadow-white/20 transition-all group">
                            Book Free Call <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
                        </a>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8" id="contact-form">
                    {/* Form */}
                    <div className="lg:col-span-3 bg-card border border-border rounded-2xl p-8 shadow-sm relative overflow-hidden opacity-0 animate-fade-in-up delay-100">
                        {/* Subtle gradient corner */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/5 to-transparent pointer-events-none" />

                        <h3 className="text-2xl font-bold mb-2 relative">Send us a message</h3>
                        <p className="text-sm text-muted-foreground mb-6 relative">We respond within 24 hours, guaranteed.</p>

                        {submitted ? (
                            <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
                                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mb-4 transition-transform active:scale-95 duration-500 animate-in zoom-in spin-in-12">
                                    <CheckCircle className="h-8 w-8 text-accent" />
                                </div>
                                <h4 className="text-xl font-bold mb-2">Message Sent!</h4>
                                <p className="text-muted-foreground">We&apos;ll get back to you within 24 hours.</p>
                            </div>
                        ) : (
                            <form onSubmit={handleSubmit} className="space-y-4 relative animate-fade-in">
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div className="group">
                                        <input
                                            type="text"
                                            name="name"
                                            value={formData.name}
                                            onChange={handleChange}
                                            placeholder="Full Name"
                                            required
                                            className="w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all placeholder:text-muted-foreground/60"
                                        />
                                    </div>
                                    <div className="group">
                                        <input
                                            type="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            placeholder="Email Address"
                                            required
                                            className="w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all placeholder:text-muted-foreground/60"
                                        />
                                    </div>
                                </div>
                                <select
                                    name="service"
                                    value={formData.service}
                                    onChange={handleChange}
                                    className="w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all"
                                >
                                    <option disabled>Select a Service</option>
                                    <option>AI Automation</option>
                                    <option>Chatbot Development</option>
                                    <option>Workflow Automation</option>
                                    <option>AI Marketing</option>
                                    <option>CRM Solutions</option>
                                    <option>Other</option>
                                </select>
                                <textarea
                                    name="message"
                                    value={formData.message}
                                    onChange={handleChange}
                                    placeholder="Tell us about your project..."
                                    rows={4}
                                    required
                                    className="w-full px-4 py-3.5 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition-all resize-none placeholder:text-muted-foreground/60"
                                />
                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    className="btn-primary group w-full sm:w-auto shadow-lg shadow-primary/20 disabled:opacity-70 disabled:cursor-not-allowed transition-all active:scale-95"
                                >
                                    {isLoading ? "Sending..." : "Send Message"} <Send className={`ml-2 h-4 w-4 ${!isLoading && "group-hover:translate-x-0.5 transition-transform"}`} />
                                </button>
                            </form>
                        )}
                    </div>

                    {/* Info cards */}
                    <div className="lg:col-span-2 space-y-4 opacity-0 animate-fade-in-up delay-200">
                        {[
                            { icon: Mail, label: "Email", value: "Hello@atulautomation.com", color: "text-primary", bg: "bg-primary/8", href: "mailto:Hello@atulautomation.com" },
                            { icon: Phone, label: "WhatsApp", value: "+91 85188 24480", color: "text-emerald-500", bg: "bg-emerald-500/8", href: "https://wa.me/918518824480" },
                            { icon: MapPin, label: "Location", value: "India · Remote Worldwide", color: "text-blue-500", bg: "bg-blue-500/8", href: "#" },
                        ].map((info, i) => {
                            const Icon = info.icon;
                            return (
                                <a key={i} href={info.href} className="block group bg-card border border-border rounded-2xl p-5 hover:border-primary/20 hover:shadow-lg transition-all duration-300">
                                    <div className="flex items-center gap-4">
                                        <div className={`w-12 h-12 rounded-xl ${info.bg} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
                                            <Icon className={`h-5 w-5 ${info.color}`} />
                                        </div>
                                        <div>
                                            <p className="text-xs text-muted-foreground font-medium mb-0.5">{info.label}</p>
                                            <p className="text-sm font-semibold group-hover:text-primary transition-colors">{info.value}</p>
                                        </div>
                                    </div>
                                </a>
                            );
                        })}

                        {/* Trust badges */}
                        <div className="bg-card border border-border rounded-2xl p-6">
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Why trust us</p>
                            <div className="grid grid-cols-2 gap-3">
                                {[
                                    { icon: Shield, label: "SSL Secured", color: "text-emerald-500" },
                                    { icon: Clock, label: "24h Response", color: "text-blue-500" },
                                    { icon: Sparkles, label: "Free Consult", color: "text-primary" },
                                    { icon: Award, label: "200+ Projects", color: "text-violet-500" },
                                ].map((t, i) => (
                                    <div key={i} className="flex items-center gap-2 bg-muted/30 p-2.5 rounded-xl hover:bg-muted/50 transition-colors">
                                        <t.icon className={`h-3.5 w-3.5 ${t.color} shrink-0`} />
                                        <span className="text-xs font-medium">{t.label}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
